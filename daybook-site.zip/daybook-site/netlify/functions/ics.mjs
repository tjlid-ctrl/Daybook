// Daybook calendar + holidays fetcher (Netlify Functions, Node 18+). No dependencies.
// GET /.netlify/functions/ics?url=<https or webcal calendar address>   -> returns the .ics text
// GET /.netlify/functions/ics?holidays=<year>&cc=<country code>        -> returns Nager.Date public holidays JSON
import dns from 'node:dns/promises';
import net from 'node:net';

const MAX_BYTES = 3_000_000;
const TIMEOUT_MS = 10_000;

function isPrivate(ip) {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split('.').map(Number);
    return a === 0 || a === 10 || a === 127 || a >= 224 || (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127);
  }
  const l = ip.toLowerCase();
  if (l.startsWith('::ffff:')) return isPrivate(l.slice(7));
  return l === '::' || l === '::1' || l.startsWith('fc') || l.startsWith('fd') || l.startsWith('fe80');
}

async function checkUrl(raw) {
  let u;
  try { u = new URL(String(raw).trim().replace(/^webcal:/i, 'https:')); } catch { return null; }
  if (u.protocol !== 'https:' || u.username || u.password || (u.port && u.port !== '443')) return null;
  const addrs = await dns.lookup(u.hostname, { all: true }).catch(() => []);
  if (!addrs.length || addrs.some(a => isPrivate(a.address))) return null;
  return u;
}

const text = (status, body, extra = {}) => new Response(body, {
  status, headers: { 'content-type': 'text/plain; charset=utf-8', 'cache-control': 'no-store', ...extra },
});

async function readCapped(res) {
  const len = Number(res.headers.get('content-length') || 0);
  if (len > MAX_BYTES) throw new Error('too-big');
  const reader = res.body.getReader();
  const chunks = []; let total = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.length;
    if (total > MAX_BYTES) { reader.cancel(); throw new Error('too-big'); }
    chunks.push(value);
  }
  return new TextDecoder().decode(Buffer.concat(chunks));
}

export default async (req) => {
  if (req.method !== 'GET') return text(405, 'Only GET is supported.');
  const q = new URL(req.url).searchParams;

  if (q.has('holidays')) {
    const year = Number(q.get('holidays')), cc = String(q.get('cc') || '').toUpperCase();
    if (!(year >= 2000 && year <= 2100) || !/^[A-Z]{2}$/.test(cc)) return text(400, 'Bad holiday request.');
    const r = await fetch(`https://date.nager.at/api/v3/PublicHolidays/${year}/${cc}`, { signal: AbortSignal.timeout(TIMEOUT_MS) }).catch(() => null);
    if (!r || !r.ok) return text(502, 'Couldn\'t load public holidays right now.');
    return new Response(await r.text(), { headers: { 'content-type': 'application/json', 'cache-control': 'public, max-age=86400' } });
  }

  let url = await checkUrl(q.get('url'));
  if (!url) return text(400, 'That isn\'t a valid calendar address. It should start with https:// or webcal://');
  try {
    for (let hop = 0; hop < 4; hop++) {
      const r = await fetch(url, { redirect: 'manual', headers: { 'user-agent': 'Daybook calendar sync', accept: 'text/calendar, */*' }, signal: AbortSignal.timeout(TIMEOUT_MS) });
      if (r.status >= 300 && r.status < 400 && r.headers.get('location')) {
        url = await checkUrl(new URL(r.headers.get('location'), url).href);
        if (!url) return text(400, 'The calendar address redirected somewhere Daybook can\'t open.');
        continue;
      }
      if (r.status === 404 || r.status === 410) return text(404, 'Calendar not found. The address may have been reset; copy it again.');
      if (r.status === 401 || r.status === 403) return text(403, 'That calendar is private. Use its secret/private iCal address.');
      if (!r.ok) return text(502, `The calendar server answered with an error (${r.status}).`);
      const body = await readCapped(r);
      if (!body.includes('BEGIN:VCALENDAR')) return text(422, 'That link didn\'t return a calendar. Check it\'s the iCal/ICS address.');
      return new Response(body, { headers: { 'content-type': 'text/calendar; charset=utf-8', 'cache-control': 'private, max-age=300' } });
    }
    return text(508, 'Too many redirects.');
  } catch (e) {
    if (e && e.message === 'too-big') return text(413, 'That calendar is too large to load (over 3 MB).');
    return text(504, 'The calendar server took too long to answer. Try again shortly.');
  }
};
