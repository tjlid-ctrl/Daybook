
(()=>{
const $=s=>document.querySelector(s);
const pad=n=>String(n).padStart(2,'0');
const key=d=>`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
const parseKey=k=>{const[y,m,d]=k.split('-').map(Number);return new Date(y,m-1,d)};
const addDays=(d,n)=>{const x=new Date(d);x.setDate(x.getDate()+n);return x};
const sod=d=>{const x=new Date(d);x.setHours(0,0,0,0);return x};
const at=(day,t)=>{const[h,m]=t.split(':').map(Number);const d=new Date(day);d.setHours(h,m,0,0);return d};
const uid=()=>Math.random().toString(36).slice(2,9);
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const DN=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const MN=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const MFULL=['January','February','March','April','May','June','July','August','September','October','November','December'];
const DFULL=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
const CAT={work:'Work',life:'Personal',uni:'Study',cal:'Calendar',due:'Due',hol:'Holidays'};
/* Public holidays: Nager.Date (date.nager.at), cached on this device per year and region */
let phMap={},calIndex={};
function loadPHCache(){const c=lsGet('daybook.ph',{});phMap={};const reg=data.settings.region,cc=data.settings.country;
  Object.values(c).forEach(y=>{if(y&&y.cc===cc)(y.list||[]).forEach(h=>{if(h.global||(h.counties||[]).includes(reg))phMap[h.date]=phMap[h.date]?phMap[h.date]+' · '+h.name:h.name})})}
async function fetchPH(year){const cc=data.settings.country;if(!cc)return;const c=lsGet('daybook.ph',{}),k=cc+year;
  if(c[k]&&Date.now()-c[k].at<7*864e5)return;
  let list=null;
  for(const u of [`https://date.nager.at/api/v3/PublicHolidays/${year}/${cc}`,`/.netlify/functions/ics?holidays=${year}&cc=${cc}`]){
    try{const r=await fetch(u);if(r.ok){list=await r.json();break}}catch(e){}}
  if(!Array.isArray(list))return;
  const c2=lsGet('daybook.ph',{});
  c2[k]={cc,at:Date.now(),list:list.map(h=>({date:h.date,name:h.localName||h.name,global:h.global!==false&&!h.counties,counties:h.counties||[]}))};
  lsSet('daybook.ph',c2);loadPHCache();full(new Date())}
function easter(y){const a=y%19,b=Math.floor(y/100),c=y%100,d=Math.floor(b/4),e=b%4,f=Math.floor((b+8)/25),g=Math.floor((b-f+1)/3),h=(19*a+b-d-g+15)%30,i=Math.floor(c/4),k=c%4,l=(32+2*e+2*i-h-k)%7,m=Math.floor((a+11*h+22*l)/451),mo=Math.floor((h+l-7*m+114)/31),da=((h+l-7*m+114)%31)+1;return new Date(y,mo-1,da)}
const nthSun=(y,m,n)=>{const d=new Date(y,m,1);return new Date(y,m,1+((7-d.getDay())%7)+7*(n-1))};
const obsCache={};
function observances(y){const ck=y+(data.settings.country||'')+JSON.stringify(data.settings.obs);if(obsCache[ck])return obsCache[ck];const o={},E=easter(y),cc=data.settings.country,ob=data.settings.obs,add=(d,n)=>{const k=key(d);o[k]=o[k]?o[k]+' · '+n:n};
  if(ob.general){add(new Date(y,1,14),"Valentine's Day");add(new Date(y,9,31),'Halloween');add(new Date(y,11,24),'Christmas Eve');add(new Date(y,11,31),"New Year's Eve");
    if(cc==='GB'||cc==='IE'){add(addDays(E,-21),"Mother's Day");add(nthSun(y,5,3),"Father's Day")}
    else if(cc==='US'||cc==='CA'){add(nthSun(y,4,2),"Mother's Day");add(nthSun(y,5,3),"Father's Day")}
    else{add(nthSun(y,4,2),"Mother's Day");add(nthSun(y,8,1),"Father's Day")}
    if(['AU','NZ','GB','CA','IE'].includes(cc))add(new Date(y,10,11),'Remembrance Day')}
  if(ob.church){add(addDays(E,-46),'Ash Wednesday');add(addDays(E,-7),'Palm Sunday');add(addDays(E,-3),'Maundy Thursday');add(addDays(E,-2),'Good Friday');add(E,'Easter Sunday');add(addDays(E,49),'Pentecost');
    const xmas=new Date(y,11,25);add(addDays(xmas,-(xmas.getDay()||7)-21),'Advent begins');add(xmas,'Christmas Day')}
  return obsCache[ck]=o}
function holidaysOn(day){const k=key(day),out=[];
  if(phMap[k])phMap[k].split(' · ').forEach(n=>{if(!out.some(o=>o.name===n))out.push({name:n,ph:true})});
  const ob=observances(day.getFullYear())[k];
  if(ob)ob.split(' · ').forEach(n=>{if(!out.some(o=>o.name===n||o.name.startsWith(n)))out.push({name:n,ph:false})});
  return out}
const isPH=day=>!!phMap[key(day)];
const cv=c=>`var(--${c})`;
const colorOf=it=>it.color||cv(it.cat);
let data;
const c24=()=>!(data&&data.settings&&data.settings.clock24===false);
const hm=d=>{const h=d.getHours(),m=pad(d.getMinutes());return c24()?`${pad(h)}:${m}`:`${h%12||12}:${m}${h<12?'am':'pm'}`};
const fmtT=t=>hm(at(new Date(2000,0,1),t));
const litres=n=>String(+(n*.25).toFixed(2));
const lsGet=(k,f)=>{try{const v=localStorage.getItem(k);return v?JSON.parse(v):f}catch(e){return f}};
const lsSet=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};
function toast(msg,act){const t=$('#toast');t.textContent='';const s=document.createElement('span');s.textContent=msg;t.append(s);
  if(act){const b=document.createElement('button');b.type='button';b.className='tbtn';b.textContent=act.label;b.onclick=()=>{t.hidden=true;act.run()};t.append(b)}
  t.hidden=false;clearTimeout(toast.t);toast.t=setTimeout(()=>t.hidden=true,act?6500:2400)}

/* ---------- schedule data (this browser) ---------- */
const STORE='daybook.v2';
function sample(){return{events:[],assessments:[]}}
function normData(d){if(!d||!Array.isArray(d.events))d=sample();
  d.assessments=Array.isArray(d.assessments)?d.assessments:[];
  d.events.forEach(e=>{e.skip=Array.isArray(e.skip)?e.skip:[]});
  const st=d.settings||{},pl=st.place||null;
  const dflt24=!/[ap]m/i.test(new Date(2000,0,1,15).toLocaleTimeString([], {hour:'numeric'}));
  d.settings={name:st.name||'',clock24:st.clock24!=null?st.clock24!==false:dflt24,hide:Array.isArray(st.hide)?st.hide:[],
    place:pl&&isFinite(pl.lat)?{name:pl.name,label:pl.label||pl.name,lat:+pl.lat,lon:+pl.lon}:null,
    country:st.country||'',region:st.region||'',obs:{general:st.obs?st.obs.general!==false:true,church:st.obs?!!st.obs.church:false}};
  d.calendars=(Array.isArray(d.calendars)?d.calendars:[]).map(c=>({id:c.id||uid(),name:c.name||'Calendar',url:c.url,color:c.color||'#5aaeff',on:c.on!==false}));
  d.workOnPH=!!d.workOnPH;d.onboarded=!!d.onboarded;if(d.onboarded&&!d.onboardedAt)d.onboardedAt=Date.now();return d}
data=normData(lsGet(STORE,null));
data.assessments.forEach(a=>{if(a.progress==null)a.progress=0;if(!a.start)a.start=key(addDays(new Date(a.due),-21))});
const save=()=>{data.updatedAt=Date.now();lsSet(STORE,data)};
let hidden=new Set(lsGet('daybook.hidden',[]));

function occursOn(ev,day){const k=key(day);if(ev.skip&&ev.skip.includes(k))return false;
  if(ev.repeat==='weekly'){if(k<ev.date)return false;if(ev.until&&k>ev.until)return false;return(ev.days||[]).includes(day.getDay())}
  return ev.date===k}
function itemsOn(day,{filter=true}={}){
  const out=[];
  for(const ev of data.events){
    if(!CAT[ev.cat]||(filter&&hidden.has(ev.cat))||!occursOn(ev,day))continue;
    if(ev.cat==='work'&&!data.workOnPH&&isPH(day))continue;
    const s=at(day,ev.start);let e=at(day,ev.end);if(e<=s)e=addDays(e,1);
    out.push({kind:'ev',id:ev.id,repeat:ev.repeat,title:ev.title,cat:ev.cat,loc:ev.loc,s,e});
  }
  if(!(filter&&hidden.has('cal'))){const k=key(day);
    for(const o of (calIndex[k]||[])){const c=data.calendars.find(x=>x.id===o.cal);if(!c||!c.on)continue;
      if(o.allDay){const s=sod(day);out.push({kind:'day',cat:'cal',color:c.color,title:o.title,loc:`All day · ${c.name}`,s,e:addDays(s,1),src:c.name})}
      else out.push({kind:'ev',cal:c.id,cat:'cal',color:c.color,src:c.name,title:o.title,loc:o.loc,s:new Date(o.s),e:new Date(o.e)})}}
  if(!(filter&&hidden.has('due'))){const k=key(day);
    for(const a of data.assessments)if(a.due.slice(0,10)===k){const s=new Date(a.due);out.push({kind:'due',id:a.id,title:a.title,cat:'due',loc:(a.course||'')+(a.weight?` · ${a.weight}%`:''),s,e:s})}}
  if(!(filter&&hidden.has('hol'))){const s=sod(day),e=addDays(s,1);
    holidaysOn(day).forEach(h=>out.push({kind:'day',title:h.name,cat:'hol',ph:h.ph,loc:h.ph?'Public holiday':'Observance',s,e}))}
  return out.sort((a,b)=>(a.kind==='day'?-1:0)-(b.kind==='day'?-1:0)||a.s-b.s);
}
const hours=it=>(it.e-it.s)/36e5;

/* ---------- formatting ---------- */
function fmtCd(ms){ms=Math.max(0,ms);const s=Math.floor(ms/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),m=Math.floor(s%3600/60),x=s%60;return(d?d+'d ':'')+`${pad(h)}:${pad(m)}:${pad(x)}`}
function fmtLeft(ms){const m=Math.max(0,Math.round(ms/6e4));if(m<60)return m+'m';const h=Math.floor(m/60);if(h<48)return `${h}h ${pad(m%60)}m`;return Math.floor(h/24)+'d '+(h%24)+'h'}
function status(s,e,now){if(now<s)return{cls:'',txt:'in '+fmtLeft(s-now)};if(now<e)return{cls:'now',txt:'Now · '+fmtLeft(e-now)+' left'};return{cls:'done',txt:+s===+e?'Passed':'Done'}}
function isoWeek(d){const t=new Date(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate()));const n=t.getUTCDay()||7;t.setUTCDate(t.getUTCDate()+4-n);const y=new Date(Date.UTC(t.getUTCFullYear(),0,1));return Math.ceil(((t-y)/864e5+1)/7)}
const monday=d=>{const x=sod(d);return addDays(x,-((x.getDay()+6)%7))};
const greeting=h=>h<5?'Good night':h<12?'Good morning':h<17?'Good afternoon':'Good evening';
function nextItems(now,n){const out=[];for(let i=0;i<30&&out.length<n+5;i++)for(const it of itemsOn(addDays(sod(now),i)))if(it.kind!=='day'&&(it.e>now||(it.kind==='due'&&it.s>now)))out.push(it);return out.sort((a,b)=>a.s-b.s).slice(0,n)}
function itemRow(it,now){
  if(it.kind==='day'){const dd=Math.round((it.s-sod(now))/864e5);
    return `<div class="item ${it.cat==='hol'?'hol':''}" ${it.src?`data-open="cal:${esc(it.src)}" role="button" tabindex="0"`:''}><div class="t"><span class="ad" style="color:${colorOf(it)}">ALL</span><small>DAY</small></div><div class="sw" style="background:${colorOf(it)}"></div>
    <div style="min-width:0"><div class="nm">${esc(it.title)}</div><div class="lc">${esc(it.loc)}</div></div><div class="st">${dd===0?'Today':dd===1?'Tomorrow':dd>0?`in ${dd} days`:''}</div></div>`}
  const st=status(it.s,it.e,now),op=it.cal?`cal:${esc(it.src)}`:it.kind==='ev'?`ev:${it.id}:${key(it.s)}`:`as:${it.id}`;
  return `<div class="item ${st.cls==='done'?'isdone':''}" data-open="${op}" role="button" tabindex="0" aria-label="Edit ${esc(it.title)}"><div class="t">${hm(it.s)}<small>${it.kind==='due'?'DUE':hm(it.e)}</small></div><div class="sw" style="background:${colorOf(it)}"></div>
  <div style="min-width:0"><div class="nm">${esc(it.title)}</div><div class="lc">${esc(it.src||CAT[it.cat])}${it.loc?' · '+esc(it.loc):''}</div></div>
  <div class="st ${st.cls}" data-s="${+it.s}" data-e="${+it.e}">${st.txt}</div></div>`}
const listHTML=(items,now,msg)=>items.length?items.map(it=>itemRow(it,now)).join(''):`<div class="empty">${msg}</div>`;

/* ---------- habits v2 (synced via db, browser fallback) ---------- */
const PLANS=[['John',21],['Mark',16],['Luke',24],['Matthew',28],['Acts',28],['Romans',16],['James',5],['Philippians',4],['Proverbs',31],['Psalms',150],['Genesis',50]];
function normCfg(c){c=c||{};const wg=(c.waterGoal&&typeof c.waterGoal==='object')?c.waterGoal:{};
  const on=c.on||{};
  return{on:{water:on.water!==false,meals:on.meals!==false,air:on.air!==false,reflect:on.reflect!==false,bible:!!on.bible},
    waterGoal:{base:+wg.base||2000,office:+wg.office||2500},commute:c.commute!=null?+c.commute:30,
    plan:(c.plan&&c.plan.book)?{book:c.plan.book,chapters:+c.plan.chapters,done:+c.plan.done||0}:{book:'John',chapters:21,done:0},
    custom:(Array.isArray(c.custom)?c.custom:[]).map(h=>({id:h.id,name:h.name,when:h.when||'day',weekly:+h.weekly||0}))}}
let habitCfg=normCfg(lsGet('daybook.habitcfg',null));
let habitDays=lsGet('daybook.habits',{});

const blankDay=()=>({air:[false,false,false],airStart:[0,0,0],waterMl:0,meals:{b:false,l:false,d:false},bible:false,custom:{},reflect:null,top3:[],top3Done:[]});
const getDay=k=>{const d=habitDays[k];if(!d)return blankDay();const b=blankDay();
  return{...b,...d,waterMl:d.waterMl!=null?d.waterMl:(d.water||0)*250,meals:{...b.meals,...(d.meals||{})},custom:{...(d.custom||{})},top3:[...(d.top3||[])],top3Done:[...(d.top3Done||[])],air:[0,1,2].map(i=>!!(d.air||[])[i]),airStart:[0,1,2].map(i=>+((d.airStart||[])[i])||0)}};
const L=ml=>`${+(ml/1000).toFixed(2)} L`;
const AIR=[['Morning','before 12:00',12],['Afternoon','12:00–17:00',17],['Evening','after 17:00',22]];
const airSlot=h=>h<12?0:h<17?1:2;
const AIRMS=15*6e4;
function airState(d,i,now){if(d.air[i])return'done';const st=d.airStart[i];if(st&&now-st<AIRMS)return'run';const h=now.getHours();return i<airSlot(h)?'missed':i===airSlot(h)?'cur':'later'}
function airHTML(d,now){const n=d.air.filter(Boolean).length;
  return `<div class="airrow"><div class="hl"><b>Fresh air</b><span>${n} of 3 · 15 min each third of the day</span></div><div class="airs">${AIR.map(([l,w],i)=>{const s=airState(d,i,now),left=d.airStart[i]+AIRMS-now;
    const txt=s==='done'?'✓ Done':s==='run'?`${pad(Math.floor(left/6e4))}:${pad(Math.floor(left%6e4/1000))} left`:s==='cur'?'Start 15 min':s==='missed'?'Missed · tap to log':'Later';
    return `<button type="button" class="air ${s}" data-air="${i}" aria-pressed="${s==='done'}" aria-label="Fresh air, ${l}"><b>${l}</b><small>${w}</small><span class="st2" data-airst="${i}">${txt}</span>${s==='run'?`<span class="fill" data-airfill="${i}" style="width:${(1-left/AIRMS)*100}%"></span>`:''}</button>`}).join('')}</div></div>`}
const isOffice=k=>itemsOn(parseKey(k),{filter:false}).some(i=>i.kind==='ev'&&/office/i.test(`${i.loc||''} ${i.title}`));
const waterGoal=k=>isOffice(k)?habitCfg.waterGoal.office:habitCfg.waterGoal.base;
function habitDefs(){const o=habitCfg.on;return[
  {id:'water',name:'Water goal',when:'all',test:(d,k)=>d.waterMl>=waterGoal(k),frac:(d,k)=>clamp(d.waterMl/waterGoal(k),0,1)},
  {id:'air',name:'Fresh air 3×15 min',when:'all',test:d=>d.air.every(Boolean),frac:d=>d.air.filter(Boolean).length/3},
  {id:'bible',name:'Bible reading',when:'morning',test:d=>!!d.bible},
  {id:'b',name:'Breakfast',when:'morning',test:d=>!!d.meals.b},
  {id:'l',name:'Lunch',when:'day',test:d=>!!d.meals.l},
  {id:'d',name:'Dinner',when:'evening',test:d=>!!d.meals.d},
  {id:'reflect',name:'Reflection',when:'evening',test:d=>!!(d.reflect&&d.reflect.rating)},
  ...habitCfg.custom.map(h=>({id:h.id,name:h.name,when:h.weekly?'week':h.when,weekly:h.weekly,custom:true,test:d=>!!d.custom[h.id]}))].filter(h=>{
    const g={water:'water',air:'air',bible:'bible',b:'meals',l:'meals',d:'meals',reflect:'reflect'}[h.id];return !g||o[g]})}
function habitScore(k){const d=getDay(k),defs=habitDefs().filter(h=>!h.weekly);
  const done=defs.reduce((s,h)=>s+(h.frac?h.frac(d,k):+h.test(d,k)),0);return{done,total:defs.length,pct:defs.length?done/defs.length:0}}
function streakOf(h){let n=0,d=sod(new Date());if(!h.test(getDay(key(d)),key(d)))d=addDays(d,-1);const miss={},thisWk=key(monday(new Date()));let grace=false;
  for(let i=0;i<400;i++){const k=key(d);if(h.test(getDay(k),k))n++;else{const w=key(monday(d));if(miss[w])break;miss[w]=1;if(w===thisWk)grace=true}d=addDays(d,-1)}
  return{n,grace}}
const streak=test=>streakOf({test}).n;
function consistency(h){let c=0;for(let i=1;i<=30;i++){const k=key(addDays(new Date(),-i));if(h.test(getDay(k),k))c++}return c}
function weekCount(id){const m=monday(new Date());let c=0;for(let i=0;i<7;i++){const k=key(addDays(m,i));if(getDay(k).custom[id])c++}return c}
function refreshHabits(){const n=new Date();renderHabits(n);renderDayProgress(n);renderInsights(n);renderWind(n);renderHabitHistory(n);renderDayInsights(n)}
function setDay(k,obj){habitDays[k]={...obj,date:k};delete habitDays[k].water;lsSet('daybook.habits',habitDays);
  refreshHabits()}
function saveCfg(){lsSet('daybook.habitcfg',habitCfg)}

/* ---------- weather: Open-Meteo (open-meteo.com), refreshed every 30 min while open ---------- */
let wx=lsGet('daybook.wx',null);
const WMO={0:'Clear',1:'Mostly clear',2:'Partly cloudy',3:'Cloudy',45:'Fog',48:'Fog',51:'Light drizzle',53:'Drizzle',55:'Heavy drizzle',56:'Freezing drizzle',57:'Freezing drizzle',61:'Light rain',63:'Rain',65:'Heavy rain',66:'Freezing rain',67:'Freezing rain',71:'Light snow',73:'Snow',75:'Heavy snow',77:'Snow grains',80:'Showers',81:'Showers',82:'Heavy showers',85:'Snow showers',86:'Snow showers',95:'Thunderstorm',96:'Storm with hail',99:'Storm with hail'};
const DIRS=['N','NNE','NE','ENE','E','ESE','SE','SSE','S','SSW','SW','WSW','W','WNW','NW','NNW'];
const dir=deg=>deg==null?'':DIRS[Math.round(deg/22.5)%16];
const placeName=()=>data.settings.place?data.settings.place.name:'Weather';
async function fetchWeather(force){const p=data.settings.place;if(!p)return;
  if(!force&&wx&&wx.lat===p.lat&&wx.lon===p.lon&&Date.now()-new Date(wx.fetched)<30*6e4)return;
  const tz=encodeURIComponent(Intl.DateTimeFormat().resolvedOptions().timeZone||'auto');
  const u=`https://api.open-meteo.com/v1/forecast?latitude=${p.lat}&longitude=${p.lon}&timezone=${tz}&forecast_days=7&wind_speed_unit=kmh`+
    `&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,wind_direction_10m`+
    `&hourly=temperature_2m,apparent_temperature,precipitation_probability,precipitation,weather_code,is_day,wind_speed_10m,wind_direction_10m,uv_index`+
    `&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum`;
  try{const r=await fetch(u);if(!r.ok)throw 0;const j=await r.json(),H=j.hourly,D=j.daily,C=j.current||{};
    wx={lat:p.lat,lon:p.lon,fetched:new Date().toISOString(),
      now:{temp:C.temperature_2m,feels:C.apparent_temperature,humidity:C.relative_humidity_2m,desc:WMO[C.weather_code]||'',wind:Math.round(C.wind_speed_10m),dir:dir(C.wind_direction_10m)},
      hourly:H.time.map((t,i)=>({t:new Date(t).toISOString(),temp:H.temperature_2m[i],feels:H.apparent_temperature[i],chance:H.precipitation_probability[i]??0,mmMin:0,mmMax:+(H.precipitation[i]||0).toFixed(1),desc:WMO[H.weather_code[i]]||'',isNight:!H.is_day[i],wind:Math.round(H.wind_speed_10m[i]),dir:dir(H.wind_direction_10m[i]),uv:H.uv_index[i]})).filter(h=>new Date(h.t)>=new Date(Date.now()-2*36e5)).slice(0,48),
      daily:D.time.map((t,i)=>({date:t,min:D.temperature_2m_min[i],max:D.temperature_2m_max[i],chance:D.precipitation_probability_max[i]??0,mmMin:0,mmMax:+(D.precipitation_sum[i]||0).toFixed(1),desc:WMO[D.weather_code[i]]||''}))};
    lsSet('daybook.wx',wx);const n=new Date();renderWeather(n);renderInsights(n);renderNow(n);renderWind(n);
  }catch(e){if(!wx)$('#wxNow').innerHTML='<div class="empty">Couldn\'t load the weather. Check your connection; it will try again shortly.</div>'}}
function wxAt(d){if(!wx||!wx.hourly)return null;let best=null,bd=Infinity;for(const h of wx.hourly){const x=Math.abs(new Date(h.t)-d);if(x<bd){bd=x;best=h}}return bd<=90*6e4?best:null}
function ago(ms){const m=Math.round(ms/6e4);if(m<60)return m+' min ago';const h=Math.round(m/60);return h<48?h+' h ago':Math.round(h/24)+' days ago'}
function tonight(now){
  if(!wx||!wx.hourly)return null;
  const t18=at(sod(now),'18:00'),from=now>t18?now:t18,to=at(addDays(sod(now),1),'06:00');
  const n=wx.hourly.filter(h=>{const d=new Date(h.t);return d>=new Date(from-36e5)&&d<to});
  if(!n.length)return{from,verdict:'Overnight outlook not in this update',short:'',detail:'',wet:false};
  const peak=n.reduce((a,b)=>(b.chance||0)>(a.chance||0)?b:a),pc=peak.chance||0;
  const mx=n.reduce((s,h)=>s+(h.mmMax||0),0),mn=n.reduce((s,h)=>s+(h.mmMin||0),0);
  return{from,pc,wet:pc>=50,verdict:pc>=50?'Rain likely tonight':pc>=25?'Possible showers tonight':'Dry night ahead',
    short:pc>=50?'Rain tonight':pc>=25?'Showers possible':'Dry night',detail:`Peak ${pc}% around ${hm(new Date(peak.t))}${mx>0?` · ${mn.toFixed(0)}–${mx.toFixed(0)} mm`:''}`};
}
function renderWeather(now){
  if(!wx||!Array.isArray(wx.hourly))return;
  const fetched=new Date(wx.fetched),stale=now-fetched>3*36e5;
  const upd=`<span class="${stale?'stale':''}">Updated ${ago(now-fetched)}</span> · <a href="https://open-meteo.com/" target="_blank" rel="noopener">Open-Meteo</a>`;
  const c=wx.now||{},h0=wxAt(now)||wx.hourly[0]||{},temp=c.temp??h0.temp,feels=c.feels??h0.feels,tn=tonight(now);
  $('#wxNow').innerHTML=`<div class="wxtemp"><div class="deg mono">${temp!=null?Math.round(temp):'–'}<sup>°C</sup></div>
    <div><div class="desc">${esc(c.desc||h0.desc||'')}</div><div class="feels">Feels ${feels!=null?Math.round(feels)+'°':'–'} · Rain ${h0.chance??'–'}% · Wind ${c.wind??h0.wind??'–'} km/h</div></div></div>
    ${tn?`<div class="tonight ${tn.wet?'wet':''}"><small>TONIGHT · ${hm(tn.from)}–06:00</small><div class="v">${tn.verdict}</div><small>${tn.detail}</small></div>`:''}`;
  const hrs=wx.hourly.filter(h=>new Date(h.t)>=new Date(now-36e5)).slice(0,24);
  if(hrs.length){
    const CW=38,W=hrs.length*CW+8,Hh=170,tT=30,tB=80,rT=98,rB=140;
    const ts=hrs.map(h=>h.temp),lo=Math.min(...ts)-1,hi=Math.max(...ts)+1;
    const tx=i=>4+i*CW+CW/2,ty=v=>tB-(v-lo)/(hi-lo||1)*(tB-tT);let g='';
    hrs.forEach((h,i)=>{if(h.isNight)g+=`<rect x="${4+i*CW}" y="0" width="${CW}" height="${Hh-14}" fill="var(--panel2)"/>`});
    g+=`<line x1="4" x2="${W-4}" y1="${rB}" y2="${rB}" stroke="var(--line)"/>`;
    hrs.forEach((h,i)=>{const bh=(h.chance||0)/100*(rB-rT);g+=`<rect x="${tx(i)-9}" y="${rB-bh}" width="18" height="${bh}" rx="2" fill="var(--work)" opacity="${.35+(h.chance||0)/160}"/>`;
      if((h.chance||0)>=10)g+=`<text class="rl" x="${tx(i)}" y="${rB-bh-4}" text-anchor="middle">${h.chance}%</text>`;
      if((h.mmMax||0)>0)g+=`<text class="hl" x="${tx(i)}" y="${rB+11}" text-anchor="middle">${h.mmMax}mm</text>`;
      g+=`<text class="hl" x="${tx(i)}" y="${Hh-2}" text-anchor="middle">${i===0?'Now':pad(new Date(h.t).getHours())}</text>`});
    const pts=hrs.map((h,i)=>`${tx(i)},${ty(h.temp)}`).join(' ');
    g+=`<polygon points="${tx(0)},${tB+6} ${pts} ${tx(hrs.length-1)},${tB+6}" fill="var(--warn)" opacity=".12"/><polyline points="${pts}" fill="none" stroke="var(--warn)" stroke-width="2" stroke-linejoin="round"/>`;
    hrs.forEach((h,i)=>{g+=`<circle cx="${tx(i)}" cy="${ty(h.temp)}" r="${i===0?4:2.5}" fill="${i===0?'var(--fg)':'var(--warn)'}"/>`;if(i%2===0)g+=`<text class="tl" x="${tx(i)}" y="${ty(h.temp)-8}" text-anchor="middle">${Math.round(h.temp)}°</text>`});
    $('#wxChart').innerHTML=`<svg width="${W}" height="${Hh}" viewBox="0 0 ${W} ${Hh}" role="img" aria-label="Hourly temperature and rain chance for ${esc(placeName())}">${g}</svg>`;
  }
  $('#wxMeta').innerHTML=`Line: temperature · Bars: chance of rain · Shaded: night · ${upd}`;
  const days=(wx.daily||[]).slice(0,7);
  if(days.length){const lo=Math.min(...days.map(d=>d.min??d.max)),hi=Math.max(...days.map(d=>d.max??d.min)),sp=hi-lo||1;
    $('#wxDays').innerHTML=days.map(d=>{const dt=parseKey(d.date),mn=d.min??d.max,mx=d.max??d.min;
      return `<div><span class="dn">${key(dt)===key(now)?'Today':DN[dt.getDay()]+' '+dt.getDate()}</span><span class="ds">${esc(d.desc||'')}</span>
      <span class="mm">${mx!=null?Math.round(mx)+'°':'–'} <span>${mn!=null?Math.round(mn)+'°':''}</span></span>
      <div class="rng"><i style="left:${(mn-lo)/sp*100}%;width:${Math.max(4,(mx-mn)/sp*100)}%"></i></div>
      <span class="rr">${d.chance??0}% rain${d.mmMax?` · ${d.mmMin||0}–${d.mmMax}mm`:''}</span></div>`}).join('')}
}


function renderBriefing(now){$('#cueTxt').textContent=NIGHT&&!data.settings.hide.includes('s-wind')?'Wind down':'Your day';document.querySelectorAll('.place').forEach(e=>e.textContent=placeName())}
function renderDayInsights(now){
  const td=getDay(key(now));
  $('#top3Today').innerHTML=td.top3.length?`<div class="top3"><b>Your top 3 today</b>${td.top3.map((t,i)=>`<button type="button" class="toggle hbtn" data-top="${i}" aria-pressed="${!!td.top3Done[i]}"><span class="box">${td.top3Done[i]?'✓':''}</span><span class="hx"><b>${esc(t)}</b></span></button>`).join('')}</div>`:'';
}
/* ---------- 01 Hello ---------- */
const GLOWS=[[5,'#6b5bff','#b44dff'],[8,'#ff9a62','#b44dff'],[16,'#b44dff','#5aaeff'],[19,'#ff3df2','#b44dff'],[24,'#b44dff','#ff3df2']];
function renderHello(now){
  const h=now.getHours(),gl=GLOWS.find(g=>h<g[0])||GLOWS[4],s=$('#s-hello');
  s.style.setProperty('--glow',gl[1]);s.style.setProperty('--glow2',gl[2]);
  $('#hello').textContent=greeting(h)+(data.settings.name?`, ${data.settings.name}`:'')+'.';
  $('#introDate').textContent=`${DFULL[now.getDay()]} ${now.getDate()} ${MFULL[now.getMonth()]} ${now.getFullYear()} · Week ${isoWeek(now)}`;
}
function renderInsights(now){
  const today=itemsOn(sod(now)).filter(i=>i.kind==='ev'),left=today.filter(i=>i.e>now);
  const wkEnd=addDays(monday(now),7);
  const upcoming=data.assessments.filter(a=>new Date(a.due)>now&&(a.progress||0)<100);
  const dueWk=upcoming.filter(a=>new Date(a.due)<wkEnd);
  const hs=habitScore(key(now)),tn=tonight(now),h0=wxAt(now),bs=streak(d=>d.bible);
  const tiles=[
    ['Today',`${left.length}<small>of ${today.length} left</small>`,left[0]?`Next: ${esc(left[0].title)} ${left[0].s<=now?'(on now)':'at '+hm(left[0].s)}`:'Nothing else on'],
    ['Due this week',`${dueWk.length}<small>${dueWk.length===1?'deadline':'deadlines'}</small>`,upcoming.length?`${upcoming.length} upcoming in total`:'Nothing due. Enjoy it'],
    ['Habits',hs.total?`${+hs.done.toFixed(1)}<small>of ${hs.total} done</small>`:'—',habitCfg.on.bible?`Bible streak: ${bs} ${bs===1?'day':'days'}`:hs.total?`${Math.round(hs.pct*100)}% of today's habits`:'Turn habits on in Settings'],
    [esc(placeName()),wx&&data.settings.place?`${Math.round(wx.now?.temp??h0?.temp??0)}°<small>${tn?tn.short:''}</small>`:'—',data.settings.place?(wx?(tn?tn.detail:''):'Loading the forecast…'):'Add your suburb in Settings']
  ];
  $('#insights').innerHTML=tiles.map(([k,v,d],i)=>`<div class="ins rise" style="--i:${3+i}"><div class="k">${k}</div><div class="v">${v}</div><div class="d">${d}</div></div>`).join('');
  const nx=nextItems(now,1)[0],parts=[];
  {const hs=holidaysOn(now);if(hs.length)parts.push(`it's <b>${esc(hs.map(h=>h.name).join(' and '))}</b>${hs.some(h=>h.ph)?' (public holiday)':''}`)}
  parts.push(left.length?`you've got <b>${left.length}</b> ${left.length===1?'thing':'things'} left today`:'your schedule is clear for the rest of today');
  if(nx)parts.push(nx.s<=now?`<b>${esc(nx.title)}</b> is on right now`:`<b>${esc(nx.title)}</b> starts in ${fmtLeft(nx.s-now)}`);
  parts.push(dueWk.length?`<b>${dueWk.length}</b> ${dueWk.length===1?'deadline is':'deadlines are'} due this week`:'no deadlines this week');
  if(tn&&tn.short&&data.settings.place)parts.push(tn.short.toLowerCase()+' in '+esc(placeName()));
  if(!data.events.length&&!data.calendars.length)parts.push('tap <b>Manage</b> to add your week or link a calendar');
  const txt=parts.join(', ')+'.';
  $('#brief').innerHTML=txt.charAt(0).toUpperCase()+txt.slice(1);
}

/* ---------- 02 Today ---------- */
function dayParts(now){
  const t0=sod(now),its=itemsOn(t0,{filter:false}).filter(i=>i.kind==='ev');
  const tot=its.reduce((s,i)=>s+hours(i),0),done=its.reduce((s,i)=>s+clamp((now-i.s)/36e5,0,hours(i)),0);
  return{elapsed:(now-t0)/864e5,sched:tot?done/tot:1,tot,done,habits:habitScore(key(now))}
}
function renderDayProgress(now){
  const p=dayParts(now),score=(p.sched+p.habits.pct)/2;
  const R=74,C=2*Math.PI*R,R2=60,C2=2*Math.PI*R2;
  $('#ringwrap').innerHTML=`<div class="ring"><svg viewBox="0 0 170 170" aria-hidden="true"><defs><linearGradient id="ng" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="var(--neon3)"/><stop offset=".6" stop-color="var(--neon)"/><stop offset="1" stop-color="var(--neon2)"/></linearGradient></defs>
      <circle cx="85" cy="85" r="${R}" fill="none" stroke="var(--line)" stroke-width="12"/>
      <circle cx="85" cy="85" r="${R}" fill="none" stroke="url(#ng)" stroke-width="12" stroke-linecap="round" stroke-dasharray="${C*score} ${C}"/>
      <circle cx="85" cy="85" r="${R2}" fill="none" stroke="var(--line)" stroke-width="5"/>
      <circle cx="85" cy="85" r="${R2}" fill="none" stroke="var(--work)" stroke-width="5" stroke-linecap="round" stroke-dasharray="${C2*p.elapsed} ${C2}"/>
    </svg><div class="c"><b>${Math.round(score*100)}%</b><small>Day score</small></div></div>
    <div class="bars">
      <div class="r"><div class="t"><span>Day elapsed</span><b>${Math.round(p.elapsed*100)}%</b></div><div class="track"><span style="width:${p.elapsed*100}%;background:var(--work)"></span></div></div>
      <div class="r"><div class="t"><span>Schedule done</span><b>${p.done.toFixed(1)} / ${p.tot.toFixed(1)} h</b></div><div class="track"><span style="width:${p.sched*100}%;background:var(--life)"></span></div></div>
      <div class="r"><div class="t"><span>Habits done</span><b>${Math.round(p.habits.pct*100)}%</b></div><div class="track"><span style="width:${p.habits.pct*100}%;background:var(--ok)"></span></div></div>
    </div>`;
  $('#dayMeta').textContent='Outer: schedule + habits · inner: time';
  const k0=key(now),d=getDay(k0),h=now.getHours()+now.getMinutes()/60,g=waterGoal(k0),ml=d.waterMl;
  const expW=Math.round(g*clamp((h-7)/(21-7),0,1)/250)*250,n=[];
  if(habitCfg.on.water)n.push(ml>=g?['ok',`Water goal reached: ${L(ml)}`]:ml>=expW?['ok',`Water on pace: ${L(ml)} of ${L(g)}`]:['warn',`Water behind: ${L(ml)}, aim for ${L(expW)} by now`]);
  const missed=[['b','breakfast',10],['l','lunch',14],['d','dinner',20]].filter(([k,,t])=>!d.meals[k]&&h>=t).map(m=>m[1]);
  if(habitCfg.on.meals)n.push(missed.length?['warn',`Not logged yet: ${missed.join(', ')}`]:['ok','Meals on track']);
  if(habitCfg.on.air){const sl=airSlot(now.getHours()),got=d.air.filter(Boolean).length,run=d.airStart.some((t,i)=>!d.air[i]&&t&&now-t<AIRMS);
   n.push(run?['ok','Fresh air break running']:got===3?['ok','Fresh air: all 3 breaks done']:d.air[sl]?['ok',`Fresh air: ${got} of 3, next one ${sl===0?'this afternoon':'this evening'}`]:['warn',`Fresh air: take your ${AIR[sl][0].toLowerCase()} 15 minutes outside (${got} of 3 so far)`])}
  if(habitCfg.on.bible)n.push(d.bible?['ok','Bible read today']:h>=20?['due','Bible reading still to do']:['muted','Bible reading still open today']);
  const col={ok:'var(--ok)',warn:'var(--warn)',due:'var(--due)',muted:'var(--faint)'};
  $('#nudges').innerHTML=n.map(([c,t])=>`<div class="nudge"><i style="background:${col[c]}"></i><span>${t}</span></div>`).join('');
  const s=Math.round(score*100);
  $('#todayHead').innerHTML=`${DFULL[now.getDay()]}, <em>${s>=70?'going strong.':s>=40?'on your way.':h<12?'just getting started.':'room to catch up.'}</em>`;
}
function renderNow(now){
  const n=nextItems(now,1)[0],el=$('#nowcard');
  if(!n){el.innerHTML='<div class="empty">Nothing scheduled in the next 30 days. Add events in Manage or link a calendar.</div>';return}
  const live=n.s<=now&&n.kind==='ev',tgt=live?n.e:n.s,f=wxAt(n.s);
  el.innerHTML=`<div class="k" style="color:${colorOf(n)}">${live?'Happening now':'Next up'} · ${n.kind==='due'?'Due':esc(n.src||CAT[n.cat])}</div>
    <h4>${esc(n.title)}</h4><div class="cd mono" data-cd="${+tgt}">${fmtCd(tgt-now)}</div>
    <div class="sub">${live?'until it ends':`until it starts · ${DN[n.s.getDay()]} ${hm(n.s)}`}${f?` · ${Math.round(f.temp)}°, ${f.chance??0}% rain`:''}</div>
    ${live?`<div class="prog"><span id="liveProg" data-s="${+n.s}" data-e="${+n.e}" style="width:${(now-n.s)/(n.e-n.s)*100}%;background:${colorOf(n)}"></span></div>`:''}`;
}
function renderSchedule(now){
  {const w=[],bad=data.calendars.filter(c=>c.on&&calErr[c.id]),old=data.calendars.filter(c=>c.on&&!calErr[c.id]&&calCache[c.id]&&Date.now()-calCache[c.id].at>24*36e5);
   if(!navigator.onLine)w.push(`You're offline. Showing what was saved${data.calendars.length?', so calendars may be out of date':''}.`);
   else{if(bad.length)w.push(`Couldn't load ${bad.map(c=>esc(c.name)).join(', ')}. Tap to check the link.`);
     if(old.length)w.push(`${old.map(c=>esc(c.name)).join(', ')} hasn't updated since ${ago(Date.now()-Math.min(...old.map(c=>calCache[c.id].at)))}.`)}
   $('#calWarn').innerHTML=w.map(t=>`<button type="button" class="warnbar" data-opencal>${t}</button>`).join('')}
  const t0=sod(now),t1=addDays(t0,1),today=itemsOn(t0),tmr=itemsOn(t1);
  $('#todayMeta').textContent=`${today.filter(i=>i.kind!=='day'&&i.e>now).length} left · ${today.filter(i=>i.kind==='ev').reduce((s,i)=>s+hours(i),0).toFixed(1)} h`;
  $('#today').innerHTML=listHTML(today,now,data.events.length||data.calendars.length?'Free day. Nothing scheduled.':'Nothing here yet. Tap Manage to add your week, or link a calendar.');
  $('#tmrHead').textContent=`Tomorrow · ${DFULL[t1.getDay()]}`;
  $('#tomorrow').innerHTML=listHTML(tmr,now,'Nothing scheduled.');
  const R0=5,R1=24,pos=d=>clamp(((d-t0)/36e5-R0)/(R1-R0)*100,0,100);
  $('#ribbon').innerHTML=today.filter(it=>it.kind!=='day').map(it=>it.kind==='due'?`<i class="dia" style="left:${pos(it.s)}%"></i>`
    :`<span class="blk" style="left:${pos(it.s)}%;width:${Math.max(.8,pos(it.e)-pos(it.s))}%;background:${colorOf(it)}" title="${esc(it.title)}"></span>`).join('')
    +`<span class="past" style="width:${pos(now)}%"></span><span class="now" style="left:${pos(now)}%"></span>`;
}
const GROUPS=[['morning','Morning'],['day','Daytime'],['evening','Evening'],['week','Weekly goals']];
const groupNow=h=>h<12?'morning':h<17?'day':'evening';
let openGrp=null;
const formBusy=sel=>{const a=document.activeElement;return a&&a.closest&&a.closest(sel)};
function habitRow(h,d,k,cue){
  const done=h.test(d,k),st=streakOf(h),c=consistency(h);
  const right=h.weekly?`<em>${weekCount(h.id)} of ${h.weekly}</em> this week`:`${st.n?`<em>${st.n}d</em> streak · `:''}${c}/30`;
  return `<div class="hitem"><button type="button" class="toggle hbtn" data-h="${h.id}" aria-pressed="${done}"><span class="box">${done?'✓':''}</span>
    <span class="hx"><b>${esc(h.label||h.name)}</b>${cue?`<small>${esc(cue)}</small>`:''}</span><span class="hs">${right}</span></button>
    ${h.custom?`<button type="button" class="x" data-rmh="${h.id}" aria-label="Remove ${esc(h.name)}">×</button>`:''}</div>`}
function bottleSVG(pct){const y=116-pct*98;
  return `<svg viewBox="0 0 60 120" width="54" height="108" aria-hidden="true"><defs><clipPath id="bclip"><path d="M23 4h14v12c0 5 13 9 13 22v72a6 6 0 0 1-6 6H16a6 6 0 0 1-6-6V38c0-13 13-17 13-22z"/></clipPath></defs>
    <g clip-path="url(#bclip)"><rect width="60" height="120" fill="var(--panel2)"/><rect y="${y}" width="60" height="120" fill="var(--water)" opacity=".9"/></g>
    <path d="M23 4h14v12c0 5 13 9 13 22v72a6 6 0 0 1-6 6H16a6 6 0 0 1-6-6V38c0-13 13-17 13-22z" fill="none" stroke="var(--water)" stroke-width="2"/></svg>`}
function renderHabits(now){
  if(formBusy('#habits form'))return;
  const k=key(now),d=getDay(k),goal=waterGoal(k),office=isOffice(k),hh=now.getHours()+now.getMinutes()/60;
  const exp=Math.round(goal*clamp((hh-7)/(21-7),0,1)/250)*250,cur=groupNow(now.getHours());
  if(!openGrp)openGrp=new Set([cur]);
  const plan=habitCfg.plan,first=itemsOn(sod(now),{filter:false}).find(i=>i.kind==='ev');
  const defs=habitDefs().filter(h=>h.id!=='water'&&h.id!=='air');
  const ch=Math.min(plan.done+(d.bible?0:1),plan.chapters);
  const label={bible:d.bible?`Read ${d.bibleRef||plan.book}`:(plan.done>=plan.chapters?`${plan.book} complete`:`Read ${plan.book} ${ch}`)};
  const cue={bible:first?`Before ${first.title} at ${hm(first.s)}`:'Any time this morning',b:`By ${fmtT('10:00')}`,l:`By ${fmtT('14:00')}`,d:`By ${fmtT('20:00')}`,reflect:'Opens in wind-down'};
  defs.forEach(h=>{if(label[h.id])h.label=label[h.id]});
  $('#habMeta').textContent=`${Math.round(habitScore(k).pct*100)}% today`;
  let html=!habitCfg.on.water?'':`<div class="wrow">${bottleSVG(clamp(d.waterMl/goal,0,1))}<div class="wt"><b>${L(d.waterMl)}</b> <span>of ${L(goal)}</span>
    <small>${office?'Office day target':'Home day target'} · ${d.waterMl>=goal?'goal reached':d.waterMl>=exp?'on pace':`aim for ${L(exp)} by now`}</small>
    <div class="wbtns"><button type="button" class="add" data-water="250">+250 ml</button><button type="button" class="add" data-water="500">+500 ml</button><button type="button" data-water="-250" aria-label="Remove 250 ml">−</button></div></div></div>`;
  if(habitCfg.on.air)html+=airHTML(d,now);
  for(const[g,gl]of GROUPS){
    const items=defs.filter(h=>h.when===g);if(!items.length)continue;
    const doneN=g==='week'?items.filter(h=>weekCount(h.id)>=h.weekly).length:items.filter(h=>h.test(d,k)).length;
    const open=openGrp.has(g);
    html+=`<div class="grp ${open?'open':''}"><button type="button" class="gh" data-grp="${g}" aria-expanded="${open}"><b>${gl}</b>${g===cur?'<span class="now">Now</span>':''}<span class="c">${doneN} of ${items.length}</span>
      <svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M3 4.5 6 7.5l3-3"/></svg></button>
      <div class="gb" ${open?'':'hidden'}>${items.map(h=>habitRow(h,d,k,cue[h.id])).join('')}
      ${g==='morning'&&habitCfg.on.bible?`<div class="plan"><span>${esc(plan.book)} · ${plan.done}/${plan.chapters}</span><div class="pbar"><span style="width:${plan.done/plan.chapters*100}%"></span></div>
        <select data-plan aria-label="Reading plan">${PLANS.map(([b,c])=>`<option value="${b}" ${b===plan.book?'selected':''}>${b} (${c})</option>`).join('')}</select></div>`:''}</div></div>`;
  }
  html+=`<form class="addh2" id="addHabit"><input id="newHabit" placeholder="New habit, e.g. Prayer" aria-label="New habit" maxlength="40">
    <select id="newWhen" aria-label="When"><option value="morning">Morning</option><option value="day">Daytime</option><option value="evening">Evening</option><option value="w2">2× a week</option><option value="w3">3× a week</option><option value="w4">4× a week</option></select>
    <button class="btn" type="submit">Add</button></form>`;
  $('#habits').innerHTML=html;
}
function toggleHabit(id){
  const k=key(new Date()),d=getDay(k);
  if(['b','l','d'].includes(id))d.meals[id]=!d.meals[id];
  else if(id==='bible'){const p=habitCfg.plan;
    if(!d.bible){if(p.done>=p.chapters){d.bible=true;d.bibleRef=p.book}else{p.done++;d.bible=true;d.bibleRef=`${p.book} ${p.done}`;saveCfg()}if(p.done>=p.chapters)toast(`${p.book} finished. Pick your next book in the plan menu.`)}
    else{if(d.bibleRef&&d.bibleRef!==p.book&&p.done>0){p.done--;saveCfg()}d.bible=false;delete d.bibleRef}}
  else if(id==='reflect'){const w=slides.findIndex(s=>s.id==='s-wind');if(w>=0){go(w);return}}
  else d.custom[id]=!d.custom[id];
  setDay(k,d)}
document.addEventListener('click',e=>{let b;
  if(b=e.target.closest('[data-h]'))toggleHabit(b.dataset.h);
  else if(b=e.target.closest('[data-air]')){const k=key(new Date()),d=getDay(k),i=+b.dataset.air,s=airState(d,i,new Date());
    if(s==='done'){d.air[i]=false;d.airStart[i]=0}
    else if(s==='run'||s==='missed'||s==='later'){d.air[i]=true;if(s!=='later')toast(s==='run'?'Fresh air logged':'Logged');else toast('Logged early')}
    else{d.airStart[i]=Date.now();toast('15 minutes of fresh air. Enjoy it')}
    setDay(k,d)}
  else if(b=e.target.closest('[data-water]')){const k=key(new Date()),d=getDay(k);d.waterMl=Math.max(0,d.waterMl+(+b.dataset.water));setDay(k,d)}
  else if(b=e.target.closest('[data-grp]')){const g=b.dataset.grp;openGrp.has(g)?openGrp.delete(g):openGrp.add(g);renderHabits(new Date())}
  else if(b=e.target.closest('[data-rmh]')){const i=habitCfg.custom.findIndex(c=>c.id===b.dataset.rmh);if(i<0)return;const[h]=habitCfg.custom.splice(i,1);saveCfg();refreshHabits();
    toast(`${h.name} removed`,{label:'Undo',run:()=>{habitCfg.custom.splice(i,0,h);saveCfg();refreshHabits()}})}
  else if(b=e.target.closest('[data-top]')){const k=key(new Date()),d=getDay(k),i=+b.dataset.top;d.top3Done[i]=!d.top3Done[i];setDay(k,d)}
  else if(b=e.target.closest('[data-rate]')){const k=key(new Date()),d=getDay(k);d.reflect={...(d.reflect||{}),rating:+b.dataset.rate,note:$('#refNote').value.trim(),grateful:$('#refGrat').value.trim()};setDay(k,d)}
});
document.addEventListener('change',e=>{const s=e.target.closest('[data-plan]');if(!s)return;const p=PLANS.find(x=>x[0]===s.value);if(!p)return;
  habitCfg.plan={book:p[0],chapters:p[1],done:0};saveCfg();s.blur();refreshHabits();toast(`Reading plan set: ${p[0]}, ${p[1]} chapters`)});
document.addEventListener('submit',e=>{
  if(e.target.id==='addHabit'){e.preventDefault();const v=$('#newHabit').value.trim();if(!v)return;const w=$('#newWhen').value;
    habitCfg.custom.push({id:uid(),name:v,when:w.startsWith('w')?'day':w,weekly:w.startsWith('w')?+w.slice(1):0});saveCfg();document.activeElement?.blur();
    if(w.startsWith('w'))openGrp.add('week');else openGrp.add(w);refreshHabits();toast('Habit added')}
  else if(e.target.id==='refForm'){e.preventDefault();const k=key(new Date()),d=getDay(k);
    d.reflect={...(d.reflect||{}),note:$('#refNote').value.trim(),grateful:$('#refGrat').value.trim()};
    if(!d.reflect.rating){toast('Pick how today felt first');return}document.activeElement?.blur();setDay(k,d);toast('Reflection saved')}
  else if(e.target.id==='top3Form'){e.preventDefault();const tk=key(addDays(new Date(),1)),d=getDay(tk);
    d.top3=['#t1','#t2','#t3'].map(x=>$(x).value.trim()).filter(Boolean);d.top3Done=d.top3.map(()=>false);document.activeElement?.blur();setDay(tk,d);toast('Saved. It\'ll be on tomorrow\'s Today slide')}
});

/* ---------- Habit history (Week slide) ---------- */
function renderHabitHistory(now){
  const today=sod(now),start=addDays(monday(now),-77),tk=key(now);
  $('#hhist').innerHTML=habitDefs().map(h=>{let cells='';
    for(let i=0;i<84;i++){const dd=addDays(start,i),k=key(dd);
      if(dd>today){cells+='<i class="f"></i>';continue}
      const d=getDay(k),ok=h.test(d,k),part=!ok&&h.frac&&h.frac(d,k)>0;
      cells+=`<i class="${ok?'y':part?'p':''} ${k===tk?'t':''}" title="${dd.toDateString()}${ok?' · done':''}"></i>`}
    const st=streakOf(h),c=consistency(h);
    return `<div class="hh"><div class="n">${esc(h.name)}</div><div class="hm">${cells}</div>
      <div class="v">${Math.round(c/30*100)}%<small>30 days</small></div><div class="v">${h.weekly?`${weekCount(h.id)}/${h.weekly}`:st.n+'d'}<small>${h.weekly?'this week':'streak'}</small></div></div>`}).join('');
}

/* ---------- Wind-down ---------- */
const RATES=[[1,'Rough'],[2,'Meh'],[3,'Okay'],[4,'Good'],[5,'Great']];
function backupDue(){if(!data.onboarded)return 0;const last=lsGet('daybook.lastBackup',0),snooze=lsGet('daybook.bkSnooze',0);if(Date.now()<snooze)return 0;
  const since=Date.now()-(last||data.onboardedAt||Date.now());return since>(last?30:7)*864e5?Math.floor(since/864e5):0}
function renderBackup(){const last=lsGet('daybook.lastBackup',0),el=$('#setLastBk');if(!el)return;
  el.textContent=last?`Last backup: ${ago(Date.now()-last)}.`:'You haven\'t downloaded a backup yet.';
  if(navigator.storage&&navigator.storage.persisted)navigator.storage.persisted().then(p=>{el.textContent+=p?' This browser has agreed to keep Daybook\'s data.':standalone?'':' Install Daybook to your Home Screen so it isn\'t cleared.'}).catch(()=>{})}
function renderWind(now){
  const k=key(now),d=getDay(k),t1=addDays(sod(now),1),tk=key(t1);
  $('#windHead').innerHTML=`Wind down. <em>Tomorrow is ${DFULL[t1.getDay()]}.</em>`;
  // close out
  const left=habitDefs().filter(h=>!h.weekly&&!h.test(d,k)&&h.id!=='reflect');const airLeft=left.some(h=>h.id==='air');
  const sc=habitScore(k);
  $('#closeMeta').textContent=`${Math.round(sc.pct*100)}% of habits`;
  {const due=backupDue(),last=lsGet('daybook.lastBackup',0);$('#bkCard').innerHTML=due?`<div class="bkcard"><b>Time for a backup</b><span>${last?`Your last backup was ${due} days ago.`:`You've used Daybook for ${due} days without a backup.`} Your data only lives on this device.</span>
    <div class="r"><button type="button" class="btn primary" data-bk>Download backup</button><button type="button" class="linkbtn" data-bksnooze>Remind me next week</button></div></div>`:''}
  $('#closeOut').innerHTML=left.length?`<div class="closed">${left.map(h=>h.id==='air'?airHTML(d,now):h.id==='water'
      ?`<div class="wrow" style="border:0;padding:0">${bottleSVG(clamp(d.waterMl/waterGoal(k),0,1))}<div class="wt"><b>${L(d.waterMl)}</b> <span>of ${L(waterGoal(k))}</span><div class="wbtns"><button type="button" class="add" data-water="250">+250 ml</button><button type="button" class="add" data-water="500">+500 ml</button></div></div></div>`
      :habitRow(h.id==='bible'?{...h,label:`Read ${habitCfg.plan.book} ${Math.min(habitCfg.plan.done+1,habitCfg.plan.chapters)}`}:h,d,k,'')).join('')}</div>`
    :`<div class="alldone">Everything's done today. Well played.</div>`;
  // reflect
  if(!formBusy('#refForm')){
    $('#rates').innerHTML=RATES.map(([n,l])=>`<button type="button" data-rate="${n}" aria-pressed="${d.reflect?.rating===n}"><b>${n}</b>${l}</button>`).join('');
    $('#refNote').value=d.reflect?.note||'';$('#refGrat').value=d.reflect?.grateful||'';
  }
  $('#refMeta').textContent=d.reflect?.rating?'Saved':'How was today?';
  // tomorrow
  const its=itemsOn(t1,{filter:false}),evs=its.filter(i=>i.kind==='ev'),out=[];
  holidaysOn(t1).forEach(h=>out.push(['★',h.name,h.ph?`Public holiday${data.workOnPH?'':'. Work is off the schedule'}`:'Observance']));
  $('#tmrMeta2').textContent=`${DN[t1.getDay()]} ${t1.getDate()} ${MN[t1.getMonth()]}`;
  if(evs.length){const f=evs[0];
    const off=/office/i.test(`${f.loc||''} ${f.title}`);
    out.push(['1',`${f.title} at ${hm(f.s)}`,off?`Leave by ${hm(new Date(+f.s-habitCfg.commute*6e4))} (${habitCfg.commute} min commute)`:(f.loc||CAT[f.cat])]);
    if(evs.length>1)out.push(['+',`${evs.length-1} more`,evs.slice(1).map(e=>`${e.title} ${hm(e.s)}`).join(' · ')]);
  }else out.push(['1','Nothing scheduled','A free day']);
  const wd=wx&&(wx.daily||[]).find(x=>x.date===tk);
  if(wd)out.push(['°',`${wd.max!=null?`High ${Math.round(wd.max)}°`:''}${wd.min!=null?`, low ${Math.round(wd.min)}°`:''}`,`${wd.chance??0}% chance of rain${(wd.chance||0)>=40?'. Take an umbrella.':''}`]);
  const soon=data.assessments.filter(a=>{const x=new Date(a.due);return x>now&&x<addDays(t1,2)&&(a.progress||0)<100});
  if(soon.length)out.push(['!',`${soon.length} due soon`,soon.map(a=>`${a.title} (${a.progress||0}%)`).join(' · ')]);
  $('#tmrPrev').innerHTML=out.map(([ic,b,t])=>`<div class="tline"><span class="ic">${ic}</span><div><b>${esc(b)}</b><br><span>${esc(t)}</span></div></div>`).join('');
  if(!formBusy('#top3Form')){const td=getDay(tk);['#t1','#t2','#t3'].forEach((x,i)=>$(x).value=td.top3[i]||'')}
}

/* ---------- 03 Week ---------- */
function renderFilters(){$('#filters').innerHTML=['work','life','uni','cal','due','hol'].filter(c=>c!=='cal'||data.calendars.length).map(c=>`<button type="button" data-f="${c}" aria-pressed="${!hidden.has(c)}"><i style="background:${cv(c)}"></i>${c==='cal'?'Calendars':CAT[c]}</button>`).join('')}
const W0=6,W1=23,HH=22;
let wkOff=0;
function renderWeek(now){
  const m=monday(addDays(now,7*wkOff)),days=[...Array(7)].map((_,i)=>addDays(m,i)),tot={work:0,life:0,uni:0,cal:0};let dues=0,leftWk=0;
  days.forEach(d=>itemsOn(d,{filter:false}).forEach(it=>{if(it.kind==='ev'){tot[it.cat]+=hours(it);leftWk+=hours(it)-clamp((now-it.s)/36e5,0,hours(it))}else if(it.kind==='due')dues++}));
  const all=tot.work+tot.life+tot.uni+tot.cal,sum=all||1,last=addDays(m,6);
  $('#wkLabel').textContent=`Week ${isoWeek(m)} · ${m.getDate()} ${MN[m.getMonth()]} – ${last.getDate()} ${MN[last.getMonth()]}`;
  const rel=wkOff===0?`${+leftWk.toFixed(1)} to go.`:wkOff===1?'Next week.':wkOff===-1?'Last week.':wkOff>0?`In ${wkOff} weeks.`:`${-wkOff} weeks ago.`;
  $('#weekHead').innerHTML=`${+all.toFixed(1)} hours booked. <em>${rel}</em>`;
  document.querySelectorAll('[data-wk="0"]').forEach(b=>b.disabled=wkOff===0);
  $('#load').innerHTML=['work','life','uni','cal'].filter(c=>c!=='cal'||tot.cal).map(c=>`<span><i style="background:${cv(c)}"></i>${CAT[c]} <b>${tot[c].toFixed(1)}h</b></span>`).join('')+`<span>Deadlines <b>${dues}</b></span><span>Free waking hours <b>${Math.max(0,112-all).toFixed(0)}h</b></span>`;
  $('#stack').innerHTML=['work','life','uni','cal'].map(c=>`<span style="width:${tot[c]/sum*100}%;background:${cv(c)}"></span>`).join('');
  const H=(W1-W0)*HH,y=d=>((d.getHours()+d.getMinutes()/60)-W0)*HH;
  const hd=d=>[...(hidden.has('hol')?[]:holidaysOn(d)),...itemsOn(d).filter(x=>x.kind==='day'&&x.cat==='cal').map(x=>({name:x.title,ph:false}))];
  let html='<div></div>'+days.map(d=>{const h=hd(d);return `<div class="dh ${key(d)===key(now)?'today':''} ${h.some(x=>x.ph)?'isph':''}">${DN[d.getDay()]}<b>${d.getDate()}</b>${h.length?`<small title="${esc(h.map(x=>x.name).join(', '))}">${esc(h[0].name)}</small>`:''}</div>`}).join('');
  html+=`<div class="hrs" style="height:${H}px">${[...Array(W1-W0+1)].map((_,i)=>i%2===0?`<span style="top:${i*HH}px">${pad(W0+i)}</span>`:'').join('')}</div>`;
  html+=days.map(d=>{const isT=key(d)===key(now);
    const dayItems=itemsOn(d),timed=dayItems.filter(it=>it.kind==='ev').sort((a,b)=>a.s-b.s||b.e-a.e),lay=new Map();
    {let cl=[],end=0;const flush=()=>{const cols=[];cl.forEach(it=>{let c=cols.findIndex(t=>t<=+it.s);if(c<0){c=cols.length;cols.push(0)}cols[c]=+it.e;lay.set(it,{c})});cl.forEach(it=>lay.get(it).n=cols.length);cl=[]};
     timed.forEach(it=>{if(cl.length&&+it.s>=end)flush();cl.push(it);end=Math.max(end,+it.e)});flush()}
    return `<div class="col ${isT?'today':''} ${hd(d).some(x=>x.ph)?'isph':''}" data-day="${key(d)}" title="Tap an empty space to add an event" style="height:${H}px;--hh:${HH}px">${dayItems.filter(it=>it.kind!=='day').map(it=>{
      if(it.kind==='due')return `<div class="dl" style="top:${clamp(y(it.s),0,H)}px" title="${esc(it.title)}"><span>DUE</span></div>`;
      const top=Math.max(0,y(it.s)),bot=Math.min(H,it.e.getDate()!==it.s.getDate()?H:y(it.e));if(bot<=0||top>=H)return '';
      return `<div class="ev" data-open="${it.cal?`cal:${esc(it.src)}`:`ev:${it.id}:${key(it.s)}`}" role="button" tabindex="0" style="top:${top}px;height:${Math.max(14,bot-top-2)}px;background:${colorOf(it)};${(l=>l&&l.n>1?`left:calc(3px + ${l.c/l.n*100}% - ${l.c/l.n*6}px);right:auto;width:calc(${100/l.n}% - ${6/l.n+2}px)`:'')(lay.get(it))}" title="${esc(it.title)} ${hm(it.s)}–${hm(it.e)}">${esc(it.title)}${bot-top>30?`<small>${hm(it.s)}–${hm(it.e)}</small>`:''}</div>`}).join('')}
      ${isT?`<div class="nl" style="top:${clamp(y(now),0,H)}px"></div>`:''}</div>`}).join('');
  $('#week').innerHTML=html;
}
document.addEventListener('click',e=>{const b=e.target.closest('[data-wk]');if(!b)return;const v=+b.dataset.wk;wkOff=v===0?0:wkOff+v;renderWeek(new Date())});
$('#week').addEventListener('click',e=>{if(e.target.closest('.ev,.dl'))return;const col=e.target.closest('.col[data-day]');if(!col)return;
  const r=col.getBoundingClientRect(),hrs=W0+Math.floor((e.clientY-r.top)/HH*2)/2,h=clamp(Math.floor(hrs),0,23),m=hrs%1?30:0;quickAdd(col.dataset.day,`${pad(h)}:${pad(m)}`)});
document.addEventListener('keydown',e=>{if(!$('#drawerRoot').hidden||/INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName||''))return;
  if(slides[active]&&slides[active].id==='s-week'&&(e.key==='ArrowLeft'||e.key==='ArrowRight')){e.preventDefault();wkOff+=e.key==='ArrowLeft'?-1:1;renderWeek(new Date())}});
let viewMonth=new Date(new Date().getFullYear(),new Date().getMonth(),1),selKey=key(new Date());
function renderUpcoming(now){const out=[],t0=sod(now);
  for(let i=0;i<400&&out.length<6;i++){const d=addDays(t0,i);holidaysOn(d).forEach(h=>{if(out.length<6)out.push({...h,d,i})})}
  $('#ups').innerHTML=out.map(h=>`<div class="up ${h.ph?'isph':''}"><div class="n">${h.i===0?'Today':h.i===1?'Tmrw':h.i}${h.i>1?'<small>days</small>':''}</div><b>${esc(h.name)}</b><span>${DFULL[h.d.getDay()]} ${h.d.getDate()} ${MN[h.d.getMonth()]}</span>${h.ph?'<em>Public holiday</em>':h.part?`<em>${esc(h.part)}</em>`:''}</div>`).join('')}
function renderMonth(now){
  $('#mLabel').textContent=`${MFULL[viewMonth.getMonth()]} ${viewMonth.getFullYear()}`;
  const start=monday(viewMonth),tk=key(now);
  let html=['M','T','W','T','F','S','S'].map(d=>`<div class="wd">${d}</div>`).join('');
  for(let i=0;i<42;i++){const d=addDays(start,i),k=key(d),its=itemsOn(d);
    const cats=[...new Set(its.filter(x=>x.kind==='ev'||x.kind==='day').map(x=>colorOf(x)))],due=its.some(x=>x.kind==='due'),ph=its.some(x=>x.kind==='day'&&x.ph);
    html+=`<button type="button" class="${[d.getMonth()!==viewMonth.getMonth()?'out':'',k<tk?'past':'',k===tk?'today':'',k===selKey?'sel':'',due?'hasdue':'',ph?'isph':''].join(' ')}" data-k="${k}" aria-label="${d.toDateString()}">${d.getDate()}<span class="dots2">${cats.slice(0,4).map(c=>`<i style="background:${c}"></i>`).join('')}</span></button>`;
    if(i===34&&addDays(start,35).getMonth()!==viewMonth.getMonth())break}
  $('#cal').innerHTML=html;
  const sd=parseKey(selKey),rel=Math.round((sd-sod(now))/864e5);
  const relTxt=rel===0?'Today':rel===1?'Tomorrow':rel===-1?'Yesterday':rel>0?`in ${rel} days`:`${-rel} days ago`;
  $('#selday').innerHTML=`<h4>${DFULL[sd.getDay()]} ${sd.getDate()} ${MN[sd.getMonth()]} <span class="mono" style="color:var(--faint);font-size:11px;font-weight:500">· ${relTxt}</span><button type="button" class="addbtn" data-qa="${selKey}" aria-label="Add an event on this day">+ Add</button></h4><div class="list">${listHTML(itemsOn(sd),now,'Nothing scheduled.')}</div>`;
}

/* ---------- 04 Assessments ---------- */
function pace(a,now){
  const due=new Date(a.due),st=at(parseKey(a.start),'00:00');
  const exp=clamp((now-st)/(due-st||1),0,1)*100,p=a.progress||0,past=due<=now;
  let lvl,lbl;
  if(p>=100){lvl='done';lbl='Done'}else if(past){lvl='past';lbl='Past due'}
  else if(p-exp>=10){lvl='ahead';lbl='Ahead'}else if(p-exp>=-10){lvl='track';lbl='On pace'}else{lvl='behind';lbl='Behind'}
  return{exp,p,lvl,lbl,due,past}
}
function renderAssess(now,force){
  const list=[...data.assessments].sort((a,b)=>a.due.localeCompare(b.due));
  const up=list.filter(a=>new Date(a.due)>now&&(a.progress||0)<100);
  const behind=up.map(a=>pace(a,now)).filter(p=>p.lvl==='behind').length;
  const wkEnd=addDays(monday(now),7),dueWk=up.filter(a=>new Date(a.due)<wkEnd).length;
  const avg=up.length?Math.round(up.reduce((s,a)=>s+(a.progress||0),0)/up.length):0;
  $('#asHead').innerHTML=!list.length?'Nothing on the books. <em>Add one when it lands.</em>':!up.length?'All caught up. <em>Nice work.</em>':behind?`${behind} behind pace. <em>Time to push.</em>`:`On top of it. <em>${up.length} to go.</em>`;
  const nx=up[0];
  $('#astats').innerHTML=`<div class="astat"><div class="k">Upcoming</div><div class="v">${up.length}</div></div>
    <div class="astat"><div class="k">Due this week</div><div class="v">${dueWk}</div></div>
    <div class="astat"><div class="k">Average progress</div><div class="v">${up.length?avg+'%':'—'}</div></div>
    <div class="astat"><div class="k">Next deadline</div><div class="v mono" ${nx?`data-cd="${+new Date(nx.due)}"`:''}>${nx?fmtCd(new Date(nx.due)-now):'—'}</div></div>`;
  const ae=document.activeElement;
  if(!force&&ae&&ae.closest&&ae.closest('#acards'))return;
  if(!list.length){$('#acards').innerHTML=`<div class="aempty"><h4>No deadlines yet</h4><p>Add an assignment, exam, bill or project. It gets a live countdown, a progress slider and a pace line that tells you whether you're ahead, on pace or behind.</p><button class="btn primary" type="button" data-addas>Add a deadline</button></div>`;return}
  const shown=list.filter(a=>new Date(a.due)>addDays(now,-14));
  $('#acards').innerHTML=shown.length?`<div class="acards">${shown.map(a=>{const p=pace(a,now),urgent=!p.past&&p.due-now<864e5&&p.lvl!=='done';
    return `<div class="acard ${urgent?'urgent':''}" data-due="${+p.due}">
      <div class="hd"><span class="code">${esc(a.course||'UNI')}${a.weight?` · ${a.weight}%`:''}</span><span class="chip ${p.lvl}">${p.lbl}</span></div>
      <div class="ttl">${esc(a.title)}</div>
      <div class="units">${['D','H','M','S'].map(u=>`<div><b data-u="${u}">--</b><small>${{D:'DAYS',H:'HRS',M:'MIN',S:'SEC'}[u]}</small></div>`).join('')}</div>
      <div class="pp"><div class="t"><span>Progress <b id="pl-${a.id}">${p.p}%</b></span><span>Pace says ${Math.round(p.exp)}%</span></div>
        <div class="dual"><span class="a" style="width:${p.p}%"></span><span class="e" style="left:${p.exp}%"></span></div>
        <input type="range" min="0" max="100" step="5" value="${p.p}" data-prog="${a.id}" id="prog-${a.id}" aria-label="Progress on ${esc(a.title)}"></div>
      <div class="due">Due ${DFULL[p.due.getDay()]} ${p.due.getDate()} ${MN[p.due.getMonth()]} · ${hm(p.due)}</div></div>`}).join('')}</div>`
    :`<div class="aempty"><h4>Nothing in the last two weeks</h4><p>Older deadlines are still listed in Manage.</p></div>`;
}
$('#acards').addEventListener('input',e=>{const r=e.target.closest('[data-prog]');if(!r)return;const l=$('#pl-'+r.dataset.prog);if(l)l.textContent=r.value+'%'});
$('#acards').addEventListener('change',e=>{const r=e.target.closest('[data-prog]');if(!r)return;const a=data.assessments.find(x=>x.id===r.dataset.prog);if(!a)return;
  a.progress=+r.value;save();r.blur();const n=new Date();renderAssess(n,true);renderInsights(n);if(a.progress>=100)toast('Marked as done. Well done!')});
$('#acards').addEventListener('click',e=>{if(e.target.closest('[data-addas]'))openDrawer('as')});
$('#addAsBtn').onclick=()=>{resetAs();openDrawer('as')};

/* ---------- deck & transitions ---------- */
const NIGHT=(h=>h>=20||h<4)(new Date().getHours());
if(NIGHT)$('#deck').insertBefore($('#s-wind'),$('#s-today'));
const deck=$('#deck');let slides=[],active=0,io=null;
function buildDeck(){
  document.querySelectorAll('.slide').forEach(sl=>{sl.hidden=data.settings.hide.includes(sl.id)});
  slides=[...document.querySelectorAll('.slide')].filter(sl=>!sl.hidden);
  slides.forEach((sl,i)=>{const b=sl.querySelector('.shead .eyebrow b');if(b)b.textContent=pad(i+1)});
  $('#dots').innerHTML=slides.map((sl,i)=>`<button type="button" data-go="${i}" aria-label="${sl.dataset.name}" aria-current="${i===active}"><span>${sl.dataset.name}</span></button>`).join('');
  active=Math.min(active,slides.length-1);
  $('#where').innerHTML=`<b>${pad(active+1)}</b> / ${pad(slides.length)} · ${slides[active].dataset.name}`;
  if(io)slides.forEach(sl=>io.observe(sl));
}
buildDeck();
const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
const go=i=>{const s=slides[clamp(i,0,slides.length-1)];deck.scrollTo({top:s.offsetTop,behavior:reduce?'auto':'smooth'})};
document.addEventListener('click',e=>{const b=e.target.closest('[data-go]');if(b)go(+b.dataset.go)});
function setActive(i){if(i===active)return;active=i;
  const s=slides[i];s.classList.remove('play');void s.offsetWidth;s.classList.add('play');
  document.querySelectorAll('#dots button').forEach((b,j)=>b.setAttribute('aria-current',j===i));
  $('#where').innerHTML=`<b>${pad(i+1)}</b> / ${pad(slides.length)} · ${s.dataset.name}`}
io=new IntersectionObserver(es=>es.forEach(e=>{const i=slides.indexOf(e.target);if(e.isIntersecting&&i>=0)setActive(i)}),{root:deck,threshold:.5});
slides.forEach(s=>io.observe(s));
slides[0].classList.add('play');
const introInner=$('#introInner'),glow=$('#glow');
deck.addEventListener('scroll',()=>{if(reduce)return;const h=slides[0].offsetHeight||1,p=clamp(deck.scrollTop/h,0,1);
  introInner.style.transform=p?`translateY(${p*-60}px) scale(${1-p*.08})`:'';introInner.style.opacity=p?1-p*.85:'';
  glow.style.transform=`scale(${1+p*.6})`;glow.style.opacity=1-p*.6;
  const nx=slides[1]&&slides[1].querySelector('.inner');if(nx)nx.style.transform=p<1?`translateY(${(1-p)*48}px)`:'';},{passive:true});
document.addEventListener('keydown',e=>{if(!$('#drawerRoot').hidden||/INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName||''))return;
  if(['ArrowDown','PageDown'].includes(e.key)){e.preventDefault();go(active+1)}else if(['ArrowUp','PageUp'].includes(e.key)){e.preventDefault();go(active-1)}});

/* ---------- live tick ---------- */
let lastMin=-1,lastDay='';
function full(now){renderBriefing(now);renderHello(now);renderInsights(now);renderDayProgress(now);renderNow(now);renderSchedule(now);renderHabits(now);renderWeek(now);renderMonth(now);renderAssess(now);renderWeather(now);renderHabitHistory(now);renderWind(now);renderUpcoming(now)}
function tick(){
  const now=new Date();
  if(now.getMinutes()!==lastMin){lastMin=now.getMinutes();if(key(now)!==lastDay){if(lastDay)selKey=key(now);lastDay=key(now)}full(now)}
  const H=now.getHours(),hh=c24()?pad(H):String(H%12||12),mm=pad(now.getMinutes()),ss=pad(now.getSeconds()),ap=c24()?'':(H<12?'am':'pm');
  $('#bigclock').innerHTML=`<b>${hh}:${mm}</b>:${ss}${ap?`<small>${ap}</small>`:''}`;$('#miniclock').textContent=`${hh}:${mm}:${ss}${ap?' '+ap:''}`;
  document.querySelectorAll('[data-cd]').forEach(el=>{const t=+el.dataset.cd;if(t<=+now)lastMin=-1;el.textContent=fmtCd(t-now)});
  document.querySelectorAll('.st[data-s]').forEach(el=>{const st=status(new Date(+el.dataset.s),new Date(+el.dataset.e),now);if(el.textContent!==st.txt){el.textContent=st.txt;el.className='st '+st.cls}});
  document.querySelectorAll('.acard[data-due]').forEach(el=>{const s=Math.floor(Math.max(0,+el.dataset.due-now)/1000);
    const v={D:Math.floor(s/86400),H:Math.floor(s%86400/3600),M:Math.floor(s%3600/60),S:s%60};el.querySelectorAll('[data-u]').forEach(b=>b.textContent=pad(v[b.dataset.u]))});
  {const k=key(now),d=getDay(k);let fin=false;
   d.airStart.forEach((t,i)=>{if(!t||d.air[i])return;const left=t+AIRMS-now;
     if(left<=0){if(now-t<AIRMS+864e5){d.air[i]=true;fin=true}return}
     document.querySelectorAll(`[data-airst="${i}"]`).forEach(el=>el.textContent=`${pad(Math.floor(left/6e4))}:${pad(Math.floor(left%6e4/1000))} left`);
     document.querySelectorAll(`[data-airfill="${i}"]`).forEach(el=>el.style.width=(1-left/AIRMS)*100+'%')});
   if(fin){setDay(k,d);toast('15 minutes done. Fresh air logged')}}
  const lp=$('#liveProg');if(lp)lp.style.width=((now-lp.dataset.s)/(lp.dataset.e-lp.dataset.s)*100)+'%';
}

/* ---------- controls ---------- */
$('#filters').addEventListener('click',e=>{const b=e.target.closest('[data-f]');if(!b)return;const c=b.dataset.f;hidden.has(c)?hidden.delete(c):hidden.add(c);lsSet('daybook.hidden',[...hidden]);renderFilters();full(new Date())});
$('#cal').addEventListener('click',e=>{const b=e.target.closest('[data-k]');if(!b)return;selKey=b.dataset.k;const d=parseKey(selKey);if(d.getMonth()!==viewMonth.getMonth())viewMonth=new Date(d.getFullYear(),d.getMonth(),1);renderMonth(new Date())});
$('#mPrev').onclick=()=>{viewMonth=new Date(viewMonth.getFullYear(),viewMonth.getMonth()-1,1);renderMonth(new Date())};
$('#mNext').onclick=()=>{viewMonth=new Date(viewMonth.getFullYear(),viewMonth.getMonth()+1,1);renderMonth(new Date())};
const th=lsGet('daybook.theme',null);if(th)document.documentElement.dataset.theme=th;
const curMode=()=>document.documentElement.dataset.theme||(matchMedia('(prefers-color-scheme: light)').matches?'light':'dark');
const syncModes=()=>{const m=curMode();document.querySelectorAll('[data-mode]').forEach(b=>b.setAttribute('aria-pressed',b.dataset.mode===m))};
const setMode=m=>{document.documentElement.dataset.theme=m;lsSet('daybook.theme',m);syncModes()};
$('#themeBtn').onclick=()=>setMode(curMode()==='dark'?'light':'dark');
document.querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>setMode(b.dataset.mode));
matchMedia('(prefers-color-scheme: light)').addEventListener?.('change',syncModes);
syncModes();

/* drawer */
function showTab(t){document.querySelectorAll('[data-tab]').forEach(x=>x.setAttribute('aria-selected',x.dataset.tab===t));
  document.querySelectorAll('[data-pane]').forEach(p=>p.hidden=p.dataset.pane!==t);if(t==='cal')renderCals()}
function openDrawer(tab){$('#drawerRoot').hidden=false;renderManage();fillSettings();showTab(tab||'ev');if(tab==='as')$('#asTitle').focus();else if(tab==='ev')$('#evTitle').focus()}
const closeDrawer=()=>{$('#drawerRoot').hidden=true;resetEv();resetAs()};
$('#manageBtn').onclick=()=>{resetEv();resetAs();openDrawer('ev')};$('#closeDrawer').onclick=closeDrawer;$('#scrim').onclick=closeDrawer;
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('#drawerRoot').hidden)closeDrawer()});
document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>showTab(b.dataset.tab));
$('#evDate').value=key(new Date());$('#asDate').value=key(addDays(new Date(),14));$('#asStart').value=key(new Date());
let selDays=new Set([new Date().getDay()]);const dayOrder=[1,2,3,4,5,6,0];
const renderDays=()=>{$('#evDays').innerHTML=dayOrder.map(d=>`<button type="button" data-d="${d}" aria-pressed="${selDays.has(d)}">${DN[d]}</button>`).join('')};renderDays();
$('#evDays').onclick=e=>{const b=e.target.closest('[data-d]');if(!b)return;const d=+b.dataset.d;selDays.has(d)?selDays.delete(d):selDays.add(d);renderDays()};
const syncRepeat=()=>{const r=$('#evRepeat').checked;$('#evDaysWrap').hidden=!r;$('#evUntilLbl').hidden=!r;$('#evDateTxt').textContent=r?'Starting from':'Date'};
$('#evRepeat').onchange=syncRepeat;syncRepeat();
$('#workPH').checked=!!data.workOnPH;
$('#workPH').onchange=e=>{data.workOnPH=e.target.checked;save();full(new Date());toast(data.workOnPH?'Work now shows on public holidays':'Work hidden on public holidays')};
let editEv=null,editDay=null,editAs=null;
function resetEv(){editEv=null;editDay=null;$('#evEditBar').hidden=true;$('#evSubmit').textContent='Add event';$('#evTitle').value='';$('#evLoc').value='';$('#evStart').value='17:00';$('#evEnd').value='18:00';$('#evRepeat').checked=true;$('#evDate').value=key(new Date());$('#evUntil').value='';selDays=new Set([new Date().getDay()]);renderDays();syncRepeat()}
function resetAs(){editAs=null;$('#asEditBar').hidden=true;$('#asSubmit').textContent='Add deadline';$('#asTitle').value='';$('#asCourse').value='';$('#asWeight').value='';$('#asDate').value=key(addDays(new Date(),14));$('#asTime').value='23:59';$('#asStart').value=key(new Date())}
function renderEvBar(){const ev=data.events.find(x=>x.id===editEv);if(!ev){resetEv();return}const bar=$('#evEditBar');bar.hidden=false;
  const dd=editDay?parseKey(editDay):null,lbl=dd?`${DN[dd.getDay()]} ${dd.getDate()} ${MN[dd.getMonth()]}`:'';
  bar.innerHTML=`<b>Editing ${esc(ev.title)}</b><div class="r">${ev.repeat==='weekly'&&editDay?`<button type="button" class="btn" data-skip="${editDay}">Skip ${lbl} only</button>`:''}<button type="button" class="btn" data-cancel-ev>Cancel</button></div>
    ${ev.skip.length?`<div class="note">Skipped days (tap to bring back):</div><div class="skips">${ev.skip.sort().map(k=>{const x=parseKey(k);return `<button type="button" data-unskip="${k}">${DN[x.getDay()]} ${x.getDate()} ${MN[x.getMonth()]} ×</button>`}).join('')}</div>`:''}`}
function quickAdd(dayKey,startHM){if($('#drawerRoot').hidden)openDrawer('ev');else showTab('ev');resetEv();
  const now=new Date(),k=dayKey||key(now);let st=startHM;
  if(!st){const h=k===key(now)?Math.min(now.getHours()+1,22):9;st=`${pad(h)}:00`}
  const[h,m]=st.split(':').map(Number),e=new Date(2000,0,1,h,m+60);
  $('#evRepeat').checked=false;syncRepeat();$('#evDate').value=k;$('#evStart').value=st;$('#evEnd').value=`${pad(e.getHours())}:${pad(e.getMinutes())}`;
  selDays=new Set([parseKey(k).getDay()]);renderDays();$('#evTitle').focus()}
document.addEventListener('click',e=>{const b=e.target.closest('[data-qa]');if(!b)return;quickAdd(b.dataset.qa||null)});
function editEvent(id,dayKey){const ev=data.events.find(x=>x.id===id);if(!ev)return;
  if($('#drawerRoot').hidden)openDrawer('ev');else showTab('ev');
  editEv=id;editDay=dayKey||null;$('#evTitle').value=ev.title;$('#evCat').value=ev.cat;$('#evLoc').value=ev.loc||'';$('#evStart').value=ev.start;$('#evEnd').value=ev.end;
  $('#evRepeat').checked=ev.repeat==='weekly';$('#evDate').value=ev.date;$('#evUntil').value=ev.until||'';selDays=new Set(ev.days||[]);renderDays();syncRepeat();
  $('#evSubmit').textContent=ev.repeat==='weekly'?'Save changes to every week':'Save changes';renderEvBar();$('#evTitle').focus()}
function editAssessment(id){const a=data.assessments.find(x=>x.id===id);if(!a)return;
  if($('#drawerRoot').hidden)openDrawer('as');else showTab('as');
  editAs=id;$('#asTitle').value=a.title;$('#asCourse').value=a.course||'';$('#asWeight').value=a.weight||'';$('#asDate').value=a.due.slice(0,10);$('#asTime').value=a.due.slice(11,16);$('#asStart').value=a.start;
  $('#asSubmit').textContent='Save changes';const bar=$('#asEditBar');bar.hidden=false;bar.innerHTML=`<b>Editing ${esc(a.title)}</b><div class="r"><span class="note">Progress stays at ${a.progress||0}%.</span><button type="button" class="btn" data-cancel-as>Cancel</button></div>`;$('#asTitle').focus()}
document.addEventListener('click',e=>{const o=e.target.closest('[data-open]');if(!o||e.target.closest('.drawer'))return;const v=o.dataset.open,[t,id,k]=v.split(':');
  if(t==='cal'){toast(`From your ${v.slice(4)} calendar. Change it in your calendar app.`);return}if(t==='ev')editEvent(id,k);else editAssessment(id)});
document.addEventListener('keydown',e=>{if(e.key!=='Enter'&&e.key!==' ')return;const o=e.target.closest&&e.target.closest('[data-open]');if(!o)return;e.preventDefault();o.click()});
$('#evForm').onsubmit=e=>{e.preventDefault();const r=$('#evRepeat').checked;if(r&&!selDays.size){toast('Pick at least one day for a weekly event');return}
  const f={title:$('#evTitle').value.trim(),cat:$('#evCat').value,loc:$('#evLoc').value.trim(),start:$('#evStart').value,end:$('#evEnd').value,repeat:r?'weekly':'none',days:r?[...selDays]:[],date:$('#evDate').value,until:r?$('#evUntil').value:''};
  if(editEv){const ev=data.events.find(x=>x.id===editEv);if(ev)Object.assign(ev,f);save();resetEv();toast('Changes saved')}
  else{data.events.push({id:uid(),skip:[],...f});save();resetEv();toast('Event added')}
  renderManage();full(new Date())};
$('#asForm').onsubmit=e=>{e.preventDefault();
  const due=$('#asDate').value+'T'+$('#asTime').value;let st=$('#asStart').value;if(st>$('#asDate').value)st=key(new Date());
  const f={title:$('#asTitle').value.trim(),course:$('#asCourse').value.trim().toUpperCase(),weight:+$('#asWeight').value||0,due,start:st};
  if(editAs){const a=data.assessments.find(x=>x.id===editAs);if(a)Object.assign(a,f);save();resetAs();toast('Changes saved')}
  else{data.assessments.push({id:uid(),...f,progress:0});save();resetAs();toast('Deadline added. Its countdown has started')}
  renderManage();full(new Date())};
function renderManage(){
  const dayStr=ev=>ev.repeat==='weekly'?'Every '+dayOrder.filter(d=>ev.days.includes(d)).map(d=>DN[d]).join(', '):(()=>{const d=parseKey(ev.date);return `${DN[d.getDay()]} ${d.getDate()} ${MN[d.getMonth()]}`})();
  $('#evList').innerHTML=data.events.length?data.events.map(ev=>`<div class="mrow"><div class="sw" style="background:${cv(ev.cat)}"></div><div style="min-width:0"><div class="nm">${esc(ev.title)}</div><div class="sub">${dayStr(ev)} · ${fmtT(ev.start)}–${fmtT(ev.end)}${ev.loc?' · '+esc(ev.loc):''}${ev.skip.length?` · ${ev.skip.length} skipped`:''}</div></div><div class="acts"><button type="button" data-edit="ev:${ev.id}">Edit</button><button type="button" data-del="ev:${ev.id}">Delete</button></div></div>`).join(''):'<div class="empty">No events yet.</div>';
  const as=[...data.assessments].sort((a,b)=>a.due.localeCompare(b.due));
  $('#asList').innerHTML=as.length?as.map(a=>{const d=new Date(a.due);return `<div class="mrow"><div class="sw" style="background:var(--uni)"></div><div style="min-width:0"><div class="nm">${esc(a.title)}</div><div class="sub">${esc(a.course||'')}${a.weight?` · ${a.weight}%`:''} · ${DN[d.getDay()]} ${d.getDate()} ${MN[d.getMonth()]} ${hm(d)} · ${a.progress||0}% done</div></div><div class="acts"><button type="button" data-edit="as:${a.id}">Edit</button><button type="button" data-del="as:${a.id}">Delete</button></div></div>`}).join(''):'<div class="empty">No deadlines yet.</div>';
}
document.querySelector('.drawer').addEventListener('click',e=>{let x;
  if(x=e.target.closest('[data-edit]')){const[t,id]=x.dataset.edit.split(':');t==='ev'?editEvent(id):editAssessment(id);return}
  if(e.target.closest('[data-cancel-ev]')){resetEv();return}
  if(e.target.closest('[data-cancel-as]')){resetAs();return}
  if(x=e.target.closest('[data-skip]')){const ev=data.events.find(v=>v.id===editEv);if(!ev)return;const k=x.dataset.skip;if(!ev.skip.includes(k))ev.skip.push(k);save();full(new Date());renderManage();const dd=parseKey(k);toast(`${ev.title} skipped on ${DN[dd.getDay()]} ${dd.getDate()} ${MN[dd.getMonth()]}`);resetEv();return}
  if(x=e.target.closest('[data-unskip]')){const ev=data.events.find(v=>v.id===editEv);if(!ev)return;ev.skip=ev.skip.filter(k=>k!==x.dataset.unskip);save();full(new Date());renderManage();renderEvBar();toast('Brought back');return}
  const b=e.target.closest('[data-del]');if(!b)return;
  const[t,id]=b.dataset.del.split(':');
  if(t==='cal'){const i=data.calendars.findIndex(x=>x.id===id);if(i<0)return;const c=data.calendars[i],cc=calCache[id];data.calendars.splice(i,1);delete calCache[id];lsSet('daybook.cal',calCache);save();rebuildCalIndex();renderCals();renderFilters();full(new Date());
    toast(`${c.name} unlinked`,{label:'Undo',run:()=>{data.calendars.splice(i,0,c);if(cc)calCache[id]=cc;lsSet('daybook.cal',calCache);save();rebuildCalIndex();renderCals();renderFilters();full(new Date());if(!cc)refreshCal(c,true)}});return}
  const list=t==='ev'?data.events:data.assessments,i=list.findIndex(x=>x.id===id);if(i<0)return;const[it]=list.splice(i,1);
  if(t==='ev'&&editEv===id)resetEv();if(t==='as'&&editAs===id)resetAs();
  save();renderManage();full(new Date());
  toast(`${it.title} deleted`,{label:'Undo',run:()=>{list.splice(i,0,it);save();renderManage();full(new Date());toast('Restored')}})});
function fillSettings(){renderBackup();$('#setName').value=data.settings.name;$('#set24').checked=data.settings.clock24;
  $('#setPlace').textContent=data.settings.place?data.settings.place.label:'Not set';$('#setCountry').value=data.settings.country;fillRegions();$('#setRegion').value=data.settings.region;
  $('#obsGen').checked=data.settings.obs.general;$('#obsChurch').checked=data.settings.obs.church;
  document.querySelectorAll('[data-hab]').forEach(c=>c.checked=!!habitCfg.on[c.dataset.hab]);
  $('#setWHome').value=habitCfg.waterGoal.base/1000;$('#setWOffice').value=habitCfg.waterGoal.office/1000;$('#setCommute').value=habitCfg.commute;
  document.querySelectorAll('[data-slide]').forEach(c=>c.checked=!data.settings.hide.includes(c.dataset.slide))}
$('#setName').addEventListener('change',e=>{data.settings.name=e.target.value.trim().slice(0,24);save();renderHello(new Date());toast('Name saved')});
$('#set24').addEventListener('change',e=>{data.settings.clock24=e.target.checked;save();full(new Date());tick();renderManage()});
['#setWHome','#setWOffice'].forEach(id=>$(id).addEventListener('change',()=>{const h=clamp(+$('#setWHome').value||2,.5,6),o=clamp(+$('#setWOffice').value||2.5,.5,6);
  habitCfg.waterGoal={base:Math.round(h*4)*250,office:Math.round(o*4)*250};saveCfg();refreshHabits();fillSettings();toast('Water targets saved')}));
$('#setCommute').addEventListener('change',e=>{habitCfg.commute=clamp(Math.round(+e.target.value||0),0,180);saveCfg();renderWind(new Date());toast('Commute saved')});
document.querySelectorAll('[data-slide]').forEach(c=>c.addEventListener('change',()=>{const id=c.dataset.slide;
  data.settings.hide=c.checked?data.settings.hide.filter(x=>x!==id):[...new Set([...data.settings.hide,id])];save();buildDeck();toast(c.checked?'Slide shown':'Slide hidden')}));

/* ---------- regions & holidays settings ---------- */
const COUNTRIES=[['AU','Australia'],['NZ','New Zealand'],['GB','United Kingdom'],['IE','Ireland'],['US','United States'],['CA','Canada'],['','No public holidays']];
const REGIONS={AU:[['AU-ACT','ACT'],['AU-NSW','New South Wales'],['AU-NT','Northern Territory'],['AU-QLD','Queensland'],['AU-SA','South Australia'],['AU-TAS','Tasmania'],['AU-VIC','Victoria'],['AU-WA','Western Australia']]};
const AU_STATE={'Australian Capital Territory':'AU-ACT','New South Wales':'AU-NSW','Northern Territory':'AU-NT','Queensland':'AU-QLD','South Australia':'AU-SA','Tasmania':'AU-TAS','Victoria':'AU-VIC','Western Australia':'AU-WA'};
function countryOpts(){return COUNTRIES.map(([c,n])=>`<option value="${c}">${n}</option>`).join('')}
function regionOpts(cc){const r=REGIONS[cc];return r?`<option value="">Whole country</option>`+r.map(([c,n])=>`<option value="${c}">${n}</option>`).join(''):''}
function fillRegions(){const cc=$('#setCountry').value;$('#setRegion').innerHTML=regionOpts(cc);$('#setRegionLbl').hidden=!REGIONS[cc]}
$('#setCountry').innerHTML=countryOpts();
function applyRegion(){obsKeysReset();loadPHCache();const y=new Date().getFullYear();fetchPH(y);fetchPH(y+1);full(new Date())}
function obsKeysReset(){for(const k in obsCache)delete obsCache[k]}
$('#setCountry').addEventListener('change',e=>{data.settings.country=e.target.value;data.settings.region='';fillRegions();save();applyRegion();toast('Holiday region saved')});
$('#setRegion').addEventListener('change',e=>{data.settings.region=e.target.value;save();applyRegion();toast('Holiday region saved')});
$('#obsGen').addEventListener('change',e=>{data.settings.obs.general=e.target.checked;save();obsKeysReset();full(new Date())});
$('#obsChurch').addEventListener('change',e=>{data.settings.obs.church=e.target.checked;save();obsKeysReset();full(new Date())});
document.querySelectorAll('[data-hab]').forEach(c=>c.addEventListener('change',()=>{habitCfg.on[c.dataset.hab]=c.checked;saveCfg();refreshHabits()}));

/* ---------- place search (Open-Meteo geocoding) ---------- */
async function searchPlaces(q){
  const r=await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=6&language=en&format=json`);
  if(!r.ok)throw 0;const j=await r.json();
  return (j.results||[]).map(p=>({name:p.name,label:[p.name,p.admin1,p.country].filter(Boolean).join(', '),lat:p.latitude,lon:p.longitude,cc:p.country_code,admin1:p.admin1}))}
function placePicker(root,onPick){
  const inp=root.querySelector('input'),list=root.querySelector('.plist');let t=null,res=[];
  inp.addEventListener('input',()=>{clearTimeout(t);const q=inp.value.trim();if(q.length<2){list.innerHTML='';return}
    t=setTimeout(async()=>{list.innerHTML='<div class="note">Searching…</div>';
      try{res=await searchPlaces(q);list.innerHTML=res.length?res.map((p,i)=>`<button type="button" data-pick="${i}">${esc(p.label)}</button>`).join(''):'<div class="note">No matches. Try a nearby suburb or town.</div>'}
      catch(e){list.innerHTML='<div class="note">Couldn\'t search right now. Check your connection.</div>'}},350)});
  list.addEventListener('click',e=>{const b=e.target.closest('[data-pick]');if(!b)return;const p=res[+b.dataset.pick];list.innerHTML='';inp.value='';onPick(p)})}
function setPlace(p){data.settings.place={name:p.name,label:p.label,lat:p.lat,lon:p.lon};
  if(p.cc&&COUNTRIES.some(c=>c[0]===p.cc)){data.settings.country=p.cc;data.settings.region=p.cc==='AU'?(AU_STATE[p.admin1]||''):''}
  save();wx=null;lsSet('daybook.wx',null);fetchWeather(true);applyRegion();fillSettings()}
placePicker($('#setPlaceBox'),p=>{setPlace(p);toast(`Location set to ${p.name}`)});

/* ---------- linked calendars (.ics) ---------- */
const CAL_COLORS=['#5aaeff','#4fd1a1','#ffb648','#ff7eb6','#b48fff','#4cc9f0','#ff8a5c'];
let calCache=lsGet('daybook.cal',{}),calErr={};
function rebuildCalIndex(){calIndex={};
  for(const c of data.calendars){const occ=(calCache[c.id]||{}).occ||[];
    for(const o of occ){if(o.allDay){let d=parseKey(o.d),end=parseKey(o.end||o.d);let n=0;do{(calIndex[key(d)]=calIndex[key(d)]||[]).push({...o,cal:c.id});d=addDays(d,1);n++}while(d<end&&n<60)}
      else{const k=key(new Date(o.s));(calIndex[k]=calIndex[k]||[]).push({...o,cal:c.id})}}}}
async function refreshCal(c,force){const ent=calCache[c.id];if(!force&&ent&&Date.now()-ent.at<30*6e4)return;
  try{const r=await fetch(`/.netlify/functions/ics?url=${encodeURIComponent(c.url)}`);const txt=await r.text();
    if(!r.ok)throw new Error(txt||'Couldn\'t load that calendar');
    const occ=expandICS(txt);calCache[c.id]={at:Date.now(),occ};delete calErr[c.id];lsSet('daybook.cal',calCache);rebuildCalIndex();full(new Date())}
  catch(e){calErr[c.id]=navigator.onLine?String(e.message||e).slice(0,140):''}
  renderSchedule(new Date());if(!$('#drawerRoot').hidden)renderCals()}
document.addEventListener('click',e=>{if(e.target.closest('[data-opencal]'))openDrawer('cal');else if(e.target.closest('[data-bk]'))exportData();else if(e.target.closest('[data-bksnooze]')){lsSet('daybook.bkSnooze',Date.now()+7*864e5);renderWind(new Date());toast('I\'ll remind you next week')}});
addEventListener('online',()=>{renderSchedule(new Date());fetchWeather();refreshAllCals(true)});addEventListener('offline',()=>renderSchedule(new Date()));
function refreshAllCals(force){data.calendars.filter(c=>c.on).forEach(c=>refreshCal(c,force))}
function renderCals(){
  $('#calList').innerHTML=data.calendars.length?data.calendars.map(c=>{const ent=calCache[c.id],err=calErr[c.id];
    return `<div class="mrow"><div class="sw" style="background:${c.color}"></div><div style="min-width:0"><div class="nm">${esc(c.name)}</div>
      <div class="sub">${err?`<span style="color:var(--due)">${esc(err)}</span>`:ent?`${ent.occ.length} events · updated ${ago(Date.now()-ent.at)}`:'Loading…'}</div></div>
      <div class="acts"><button type="button" data-caltog="${c.id}">${c.on?'Hide':'Show'}</button><button type="button" data-calref="${c.id}">Refresh</button><button type="button" data-del="cal:${c.id}">Remove</button></div></div>`}).join(''):'<div class="empty">No calendars linked yet.</div>'}
function addCalendar(name,url){url=url.trim().replace(/^webcal:\/\//i,'https://');
  if(!/^https:\/\//i.test(url)){toast('Paste the full calendar address. It starts with https:// or webcal://');return false}
  const c={id:uid(),name:name.trim()||'Calendar',url,color:CAL_COLORS[data.calendars.length%CAL_COLORS.length],on:true};
  data.calendars.push(c);save();renderCals();renderFilters();refreshCal(c,true);return true}
$('#calForm').addEventListener('submit',e=>{e.preventDefault();if(addCalendar($('#calName').value,$('#calUrl').value)){$('#calName').value='';$('#calUrl').value='';toast('Calendar linked. Loading events…')}});
$('#calList').addEventListener('click',e=>{let b;
  if(b=e.target.closest('[data-caltog]')){const c=data.calendars.find(x=>x.id===b.dataset.caltog);c.on=!c.on;save();renderCals();full(new Date());if(c.on)refreshCal(c)}
  else if(b=e.target.closest('[data-calref]')){const c=data.calendars.find(x=>x.id===b.dataset.calref);calErr[c.id]='';renderCals();refreshCal(c,true)}});

/* ICS parsing with recurrence (RRULE: DAILY/WEEKLY/MONTHLY/YEARLY, INTERVAL, COUNT, UNTIL, BYDAY, BYMONTHDAY, BYMONTH), EXDATE and overrides */
const WINTZ={'AUS Eastern Standard Time':'Australia/Sydney','E. Australia Standard Time':'Australia/Brisbane','Cen. Australia Standard Time':'Australia/Adelaide','AUS Central Standard Time':'Australia/Darwin','W. Australia Standard Time':'Australia/Perth','Tasmania Standard Time':'Australia/Hobart','New Zealand Standard Time':'Pacific/Auckland','GMT Standard Time':'Europe/London','Eastern Standard Time':'America/New_York','Central Standard Time':'America/Chicago','Mountain Standard Time':'America/Denver','Pacific Standard Time':'America/Los_Angeles','UTC':'UTC'};
const tzFmt={};
function tzOffset(tz,ms){try{const f=tzFmt[tz]||(tzFmt[tz]=new Intl.DateTimeFormat('en-US',{timeZone:tz,hourCycle:'h23',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'}));
  const p={};f.formatToParts(new Date(ms)).forEach(x=>p[x.type]=x.value);return Date.UTC(+p.year,+p.month-1,+p.day,+p.hour%24,+p.minute,+p.second)-ms}catch(e){return null}}
function wallToMs(w,tz){if(w.utc)return Date.UTC(w.y,w.mo,w.d,w.h,w.mi,w.s);
  const z=tz&&(WINTZ[tz]||tz);const guess=Date.UTC(w.y,w.mo,w.d,w.h,w.mi,w.s);
  if(z){const o1=tzOffset(z,guess);if(o1!=null){const o2=tzOffset(z,guess-o1);return guess-(o2!=null?o2:o1)}}
  return new Date(w.y,w.mo,w.d,w.h,w.mi,w.s).getTime()}
function parseDT(v,params){const m=/^(\d{4})(\d{2})(\d{2})(?:T(\d{2})(\d{2})(\d{2})?(Z)?)?/.exec(v||'');if(!m)return null;
  return{y:+m[1],mo:+m[2]-1,d:+m[3],h:+(m[4]||0),mi:+(m[5]||0),s:+(m[6]||0),utc:!!m[7],date:!m[4]||/VALUE=DATE(?!-)/.test(params||''),tz:(/TZID=([^;:]+)/.exec(params||'')||[])[1]}}
function parseDur(v){const m=/^([+-])?P(?:(\d+)W)?(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?/.exec(v||'');if(!m)return 0;return((+(m[2]||0)*7+ +(m[3]||0))*864e5+ +(m[4]||0)*36e5+ +(m[5]||0)*6e4+ +(m[6]||0)*1e3)*(m[1]==='-'?-1:1)}
const unesc=t=>(t||'').replace(/\\n/gi,' ').replace(/\\([,;\\])/g,'$1').trim();
function expandICS(txt){
  if(!/BEGIN:VCALENDAR/.test(txt))throw new Error('That link didn\'t return a calendar. Check it\'s the private iCal/ICS address.');
  const lines=txt.replace(/\r\n[ \t]/g,'').replace(/\n[ \t]/g,'').split(/\r?\n/);
  const evs=[];let cur=null,depth=0;
  for(const ln of lines){
    if(ln==='BEGIN:VEVENT'){cur={ex:[]};continue}
    if(ln==='END:VEVENT'){if(cur)evs.push(cur);cur=null;continue}
    if(!cur)continue;if(/^BEGIN:/.test(ln)){depth++;continue}if(/^END:/.test(ln)){depth--;continue}if(depth>0)continue;
    const i=ln.indexOf(':');if(i<0)continue;const head=ln.slice(0,i),val=ln.slice(i+1),name=head.split(';')[0].toUpperCase(),params=head.slice(name.length);
    if(name==='SUMMARY')cur.title=unesc(val);else if(name==='LOCATION')cur.loc=unesc(val);else if(name==='UID')cur.uid=val;else if(name==='STATUS')cur.status=val;
    else if(name==='DTSTART')cur.ds=parseDT(val,params);else if(name==='DTEND')cur.de=parseDT(val,params);else if(name==='DURATION')cur.dur=parseDur(val);
    else if(name==='RRULE')cur.rr=Object.fromEntries(val.split(';').map(x=>x.split('=')));
    else if(name==='EXDATE')val.split(',').forEach(v=>{const d=parseDT(v,params);if(d)cur.ex.push(d)});
    else if(name==='RECURRENCE-ID')cur.rid=parseDT(val,params)}
  const W0=sod(addDays(new Date(),-60)).getTime(),W1=sod(addDays(new Date(),400)).getTime(),out=[];
  const toMs=w=>wallToMs(w,w.tz),dkey=w=>`${w.y}-${pad(w.mo+1)}-${pad(w.d)}`;
  const overrides={};evs.filter(e=>e.rid&&e.uid).forEach(e=>{(overrides[e.uid]=overrides[e.uid]||new Set()).add(e.rid.date?dkey(e.rid):toMs(e.rid))});
  const emit=(e,w)=>{if(e.ds.date){const sd=new Date(w.y,w.mo,w.d),len=e.de&&e.de.date?Math.max(1,Math.round((Date.UTC(e.de.y,e.de.mo,e.de.d)-Date.UTC(e.ds.y,e.ds.mo,e.ds.d))/864e5)):Math.max(1,Math.round((e.dur||864e5)/864e5));
      const end=addDays(sd,len);if(end.getTime()<W0||sd.getTime()>W1)return;out.push({allDay:true,d:key(sd),end:key(end),title:e.title||'Busy',loc:e.loc||''})}
    else{const s=wallToMs(w,e.ds.tz),len=e.de?toMs(e.de)-toMs(e.ds):(e.dur||36e5);if(s+len<W0||s>W1)return;out.push({allDay:false,s,e:s+Math.max(len,0),title:e.title||'Busy',loc:e.loc||''})}};
  for(const e of evs){
    if(!e.ds||e.status==='CANCELLED')continue;
    if(e.rid||!e.rr){emit(e,e.ds);continue}
    const r=e.rr,F=r.FREQ,iv=Math.max(1,+r.INTERVAL||1),cnt=r.COUNT?+r.COUNT:Infinity,until=r.UNTIL?parseDT(r.UNTIL):null;
    const untilMs=until?(until.date?Date.UTC(until.y,until.mo,until.d,23,59,59):(until.utc?toMs(until):wallToMs(until,e.ds.tz))):Infinity;
    const exs=new Set(e.ex.map(x=>x.date||e.ds.date?dkey(x):toMs({...x,tz:x.tz||e.ds.tz})));const ov=overrides[e.uid]||new Set();
    const BYD=r.BYDAY?r.BYDAY.split(',').map(x=>{const m=/^([+-]?\d+)?(MO|TU|WE|TH|FR|SA|SU)$/.exec(x);return m?{n:m[1]?+m[1]:0,wd:['SU','MO','TU','WE','TH','FR','SA'].indexOf(m[2])}:null}).filter(Boolean):null;
    const BYMD=r.BYMONTHDAY?r.BYMONTHDAY.split(',').map(Number):null,BYM=r.BYMONTH?r.BYMONTH.split(',').map(x=>+x-1):null;
    const base=Date.UTC(e.ds.y,e.ds.mo,e.ds.d),ds=e.ds;let n=0,guard=0;
    const daysIn=(y,m)=>new Date(Date.UTC(y,m+1,0)).getUTCDate();
    const monthDays=(y,m)=>{let ds2=[];const dim=daysIn(y,m);
      if(BYD){for(const b of BYD){const all=[];for(let d=1;d<=dim;d++)if(new Date(Date.UTC(y,m,d)).getUTCDay()===b.wd)all.push(d);
        if(!b.n)ds2.push(...all);else{const p=b.n>0?all[b.n-1]:all[all.length+b.n];if(p)ds2.push(p)}}}
      else ds2=(BYMD||[ds.d]).map(d=>d<0?dim+d+1:d).filter(d=>d>=1&&d<=dim);
      if(BYD&&BYMD)ds2=ds2.filter(d=>BYMD.includes(d));return [...new Set(ds2)].sort((a,b)=>a-b)};
    const tryDay=(t)=>{if(n>=cnt)return false;const dt=new Date(t),w={y:dt.getUTCFullYear(),mo:dt.getUTCMonth(),d:dt.getUTCDate(),h:ds.h,mi:ds.mi,s:ds.s,utc:ds.utc,tz:ds.tz,date:ds.date};
      if(t<base)return true;const ms=ds.date?Date.UTC(w.y,w.mo,w.d):wallToMs(w,ds.tz);if(ms>untilMs)return false;if(ms>W1+864e5)return false;
      n++;const k=ds.date?dkey(w):ms;if(!exs.has(k)&&!ov.has(k))emit(e,w);return true};
    let go=true;
    if(F==='DAILY'){for(let t=base;go&&guard<20000;t+=iv*864e5,guard++){const dt=new Date(t);if(BYM&&!BYM.includes(dt.getUTCMonth()))continue;if(BYD&&!BYD.some(b=>b.wd===dt.getUTCDay()))continue;go=tryDay(t)}}
    else if(F==='WEEKLY'){const wds=BYD?BYD.map(b=>b.wd):[new Date(base).getUTCDay()];const wkStart=base-((new Date(base).getUTCDay()+6)%7)*864e5;
      for(let w0=wkStart;go&&guard<5000;w0+=iv*7*864e5,guard++){for(let i=0;i<7&&go;i++){const t=w0+i*864e5;if(wds.includes(new Date(t).getUTCDay()))go=tryDay(t)}}}
    else if(F==='MONTHLY'){for(let y=ds.y,m=ds.mo;go&&guard<2400;guard++){if(!BYM||BYM.includes(m))for(const d of monthDays(y,m)){go=tryDay(Date.UTC(y,m,d));if(!go)break}m+=iv;y+=Math.floor(m/12);m%=12}}
    else if(F==='YEARLY'){for(let y=ds.y;go&&guard<200;y+=iv,guard++){for(const m of (BYM||[ds.mo])){const dl=BYD||BYMD?monthDays(y,m):[ds.d].filter(d=>d<=daysIn(y,m));for(const d of dl){go=tryDay(Date.UTC(y,m,d));if(!go)break}if(!go)break}}}
    else emit(e,e.ds)}
  return out}

/* ---------- data: export, import, erase ---------- */
function exportData(){const blob=new Blob([JSON.stringify({app:'daybook',version:1,exported:new Date().toISOString(),data,habitCfg,habitDays},null,1)],{type:'application/json'});
  const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`daybook-backup-${key(new Date())}.json`;lsSet('daybook.lastBackup',Date.now());document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},500);toast('Backup downloaded. Keep it somewhere safe, like Files or iCloud Drive.');renderBackup();renderWind(new Date())}
$('#expBtn').onclick=exportData;
$('#impFile').addEventListener('change',async e=>{const f=e.target.files[0];if(!f)return;
  try{const j=JSON.parse(await f.text());if(j.app!=='daybook'||!j.data)throw 0;
    data=normData(j.data);habitCfg=normCfg(j.habitCfg);habitDays=j.habitDays||{};save();saveCfg();lsSet('daybook.habits',habitDays);
    loadPHCache();rebuildCalIndex();buildDeck();renderFilters();fillSettings();renderManage();full(new Date());refreshAllCals(true);fetchWeather(true);toast('Backup restored')}
  catch(err){toast('That file isn\'t a Daybook backup.')}e.target.value=''});
$('#eraseBtn').addEventListener('click',e=>{const b=e.currentTarget;
  if(!b.classList.contains('arm')){b.classList.add('arm');b.textContent='Tap again to erase everything';setTimeout(()=>{if(b.isConnected){b.classList.remove('arm');b.textContent='Erase all data on this device'}},4000);return}
  try{Object.keys(localStorage).filter(k=>k.startsWith('daybook.')).forEach(k=>localStorage.removeItem(k))}catch(err){}
  location.reload()});

/* ---------- welcome setup ---------- */
const onb={step:0,place:null,days:new Set([1,2,3,4,5])};
function onbShow(i){onb.step=i;document.querySelectorAll('.onb-step').forEach((s,j)=>s.hidden=j!==i);
  document.querySelectorAll('.onb-dots i').forEach((d,j)=>d.classList.toggle('on',j<=i));
  $('#onbBack').hidden=i===0;$('#onbNext').textContent=i===3?'Start my Daybook':'Next';
  const f=document.querySelectorAll('.onb-step')[i].querySelector('input,button.pill');if(f&&i!==3)setTimeout(()=>f.focus(),50)}
function onbDays(){$('#onbDays').innerHTML=[1,2,3,4,5,6,0].map(d=>`<button type="button" data-od="${d}" aria-pressed="${onb.days.has(d)}">${DN[d]}</button>`).join('')}
$('#onbDays').addEventListener('click',e=>{const b=e.target.closest('[data-od]');if(!b)return;const d=+b.dataset.od;onb.days.has(d)?onb.days.delete(d):onb.days.add(d);onbDays()});
placePicker($('#onbPlaceBox'),p=>{onb.place=p;$('#onbPicked').innerHTML=`<b>${esc(p.label)}</b>`;
  if(p.cc&&COUNTRIES.some(c=>c[0]===p.cc)){$('#onbCountry').value=p.cc;onbRegions();if(p.cc==='AU')$('#onbRegion').value=AU_STATE[p.admin1]||''}});
$('#onbCountry').innerHTML=countryOpts();
function onbRegions(){const cc=$('#onbCountry').value;$('#onbRegion').innerHTML=regionOpts(cc);$('#onbRegionLbl').hidden=!REGIONS[cc]}
$('#onbCountry').addEventListener('change',onbRegions);
$('#onbWork').addEventListener('change',e=>{$('#onbWorkBox').hidden=!e.target.checked});
function finishOnb(){
  data.settings.name=$('#onbName').value.trim().slice(0,24);
  if(onb.place)data.settings.place={name:onb.place.name,label:onb.place.label,lat:onb.place.lat,lon:onb.place.lon};
  data.settings.country=$('#onbCountry').value;data.settings.region=$('#onbRegion').value||'';
  data.settings.obs.church=$('#onbChurch').checked;data.settings.clock24=$('#onb24').checked;
  document.querySelectorAll('[data-ohab]').forEach(c=>habitCfg.on[c.dataset.ohab]=c.checked);
  if($('#onbWork').checked&&onb.days.size){const s0=$('#onbWS').value||'09:00',e0=$('#onbWE').value||'17:00';
    data.events.push({id:uid(),title:$('#onbWT').value.trim()||'Work',cat:'work',loc:'',start:s0,end:e0,repeat:'weekly',days:[...onb.days],date:key(new Date()),until:'',skip:[]})}
  const cu=$('#onbCalUrl').value.trim();
  data.onboarded=true;data.onboardedAt=Date.now();save();saveCfg();askPersist();
  if(cu)addCalendar($('#onbCalName').value||'My calendar',cu);
  $('#onbRoot').hidden=true;document.body.classList.remove('onb-open');
  loadPHCache();const y=new Date().getFullYear();fetchPH(y);fetchPH(y+1);fetchWeather(true);buildDeck();renderFilters();full(new Date());
  showInstall();toast(data.settings.name?`Welcome, ${data.settings.name}.`:'Welcome to Daybook.')}
$('#onbNext').onclick=()=>{if(onb.step<3)onbShow(onb.step+1);else finishOnb()};
$('#onbBack').onclick=()=>onbShow(Math.max(0,onb.step-1));
$('#onbSkip').onclick=()=>finishOnb();
$('#onbForm').addEventListener('submit',e=>{e.preventDefault();$('#onbNext').click()});
function startOnb(){$('#onbRoot').hidden=false;document.body.classList.add('onb-open');$('#onb24').checked=data.settings.clock24;onbRegions();onbDays();onbShow(0)}

/* ---------- install tip (iPhone/iPad Safari) ---------- */
const standalone=matchMedia('(display-mode: standalone)').matches||navigator.standalone===true;
const iOS=/iphone|ipad|ipod/i.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1);
document.querySelectorAll('.install-tip').forEach(el=>el.hidden=standalone);
if(iOS)document.querySelectorAll('.install-ios').forEach(el=>el.hidden=false);

/* ---------- keep data safe & install ---------- */
function askPersist(){try{navigator.storage&&navigator.storage.persist&&navigator.storage.persist().catch(()=>{})}catch(e){}}
let deferredInstall=null;
addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstall=e;showInstall()});
function showInstall(){const bar=$('#installBar');if(standalone||!data.onboarded){bar.hidden=true;return}
  if(Date.now()<lsGet('daybook.installSnooze',0)){bar.hidden=true;return}
  if(iOS){bar.hidden=false;$('#installMsg').innerHTML='Add Daybook to your Home Screen. It opens full screen, and your iPhone won\'t clear your data.';$('#installGo').textContent='Show me how'}
  else if(deferredInstall){bar.hidden=false;$('#installMsg').textContent='Install Daybook as an app so it opens full screen and keeps your data safe.';$('#installGo').textContent='Install'}
  else bar.hidden=true}
$('#installGo').onclick=async()=>{if(deferredInstall){deferredInstall.prompt();const r=await deferredInstall.userChoice.catch(()=>null);deferredInstall=null;$('#installBar').hidden=true;if(r&&r.outcome==='accepted')toast('Installed. Open Daybook from your apps.')}
  else if($('#installGo').dataset.step){lsSet('daybook.installSnooze',Date.now()+14*864e5);$('#installBar').hidden=true}
  else{$('#installMsg').innerHTML='In Safari, tap the <b>Share</b> button <span aria-hidden="true">(the square with an arrow)</span>, scroll down and tap <b>Add to Home Screen</b>, then <b>Add</b>.';$('#installGo').textContent='Got it';$('#installGo').dataset.step='1';$('#installLater').hidden=true}};
$('#installLater').onclick=()=>{lsSet('daybook.installSnooze',Date.now()+14*864e5);$('#installBar').hidden=true};
addEventListener('appinstalled',()=>{$('#installBar').hidden=true});

/* ---------- start ---------- */
loadPHCache();rebuildCalIndex();
renderFilters();tick();setInterval(tick,1000);
if(!data.onboarded)startOnb();
else{askPersist();showInstall();const y=new Date().getFullYear();fetchPH(y);fetchPH(y+1);fetchWeather();refreshAllCals()}
setInterval(()=>{fetchWeather();refreshAllCals()},5*6e4);
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'){fetchWeather();refreshAllCals();lastMin=-1}});
if('serviceWorker' in navigator&&location.protocol==='https:'){const had=!!navigator.serviceWorker.controller;
  navigator.serviceWorker.register('/sw.js').then(reg=>{document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')reg.update().catch(()=>{})});setInterval(()=>reg.update().catch(()=>{}),60*6e4)}).catch(()=>{});
  navigator.serviceWorker.addEventListener('controllerchange',()=>{if(had)$('#updBar').hidden=false})}
$('#updGo').onclick=()=>location.reload();
})();
