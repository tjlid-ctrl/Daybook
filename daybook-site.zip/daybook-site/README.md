# Daybook

A live dashboard for your day, week and deadlines: greeting and quick stats, today's schedule with habits and weather, the week ahead with public holidays, deadline countdowns and an evening wind-down. It installs on iPhone and Android as a home-screen app.

## What's in this folder

| Path | What it is |
|---|---|
| `public/` | The website: `index.html`, `app.js`, `styles.css`, the app manifest, the offline service worker (`sw.js`) and icons |
| `netlify/functions/ics.mjs` | A small server function that fetches linked calendars (and public holidays as a backup source) |
| `netlify.toml` | Netlify settings: where the site and function live, plus security headers |

There's nothing to install or build. No npm packages.

## Put it online with Netlify

The calendar function only deploys when Netlify builds from Git or the Netlify command line. Dragging the folder onto Netlify's website publishes the pages but **not** the function, so calendar linking wouldn't work.

### Option A: GitHub (no command line)

1. Create a free account at github.com. Make a new repository called `daybook`, then upload everything in this folder (use **Add file › Upload files**; keep the folder structure).
2. Create a free account at netlify.com. Choose **Add new site › Import an existing project › GitHub** and pick `daybook`.
3. Netlify reads `netlify.toml` itself. Leave the build command empty and press **Deploy**.
4. You'll get an address like `daybook-abc123.netlify.app`. Change it under **Site configuration › Change site name**, or add your own domain under **Domain management**.

Every time you upload changed files to GitHub, Netlify redeploys automatically.

### Option B: Netlify command line

Needs Node.js on your computer. In this folder, run:

```
npx netlify-cli login
npx netlify-cli deploy --prod
```

Choose "Create & configure a new site" the first time.

## Install it on an iPhone

1. Open your Daybook address in **Safari**.
2. Tap the **Share** button, then **Add to Home Screen**, then **Add**.
3. Open it from the home screen. It runs full screen, with no browser bars, and works offline.

On Android, open it in Chrome and choose **Install app** from the menu.

## When you update the site

Daybook always fetches the newest files when it's online, so changes show up the next time it's opened. If you also change `VERSION` in `public/sw.js` (for example `daybook-v2` to `daybook-v3`), anyone with Daybook open gets a "New version ready, Refresh" message straight away.

## How it works

- **Data stays on each person's device.** No accounts and no database. Settings › Your data has backup download, restore and erase. Daybook asks the browser to keep its data, nudges iPhone users to add it to the Home Screen (Safari can clear data for sites that aren't installed and haven't been opened for about a week), and reminds people in Wind-down to download a backup about once a month.
- **Weather** comes from [Open-Meteo](https://open-meteo.com/) for any suburb or town, refreshed every 30 minutes while Daybook is open.
- **Public holidays** come from [Nager.Date](https://date.nager.at/) for Australia (by state), New Zealand, the UK, Ireland, the US and Canada. Days like Mother's Day and the church calendar are calculated in the app.
- **Linked calendars**: people paste their private iCal/ICS address (Google, Outlook, iCloud, uni timetables). The server function fetches it and the app expands repeating events, skipped dates and time zones. Linked calendars are read-only and refresh every 30 minutes while open.

## Everyday features

- **+ Add** on the Today schedule and the month view, or tap any empty spot in the week grid, to add a one-off event at that time.
- **‹ This week ›** on the Week slide (or the ← → keys) to look ahead or back.
- Deleting an event, deadline, calendar or habit shows an **Undo** button for a few seconds.
- If a linked calendar stops loading, or you're offline, a warning shows on the Today slide. Tap it to fix the link.

## Before you launch publicly

- **Open-Meteo's free plan is for non-commercial use.** If Daybook makes money (ads, subscriptions), you'll need their paid API plan. The attribution link they require is already on the weather panels.
- **The name "Daybook"** is already used by other apps, including a journaling app on the App Store. Check it before you build a brand around it.
- **Add a privacy page.** A short one is enough: data stays on the device, calendar addresses pass through the server function only to fetch them and aren't stored, and weather lookups send the chosen location to Open-Meteo.
- **Not included yet:** sync between a person's devices, push notifications, and a native App Store app. These are the natural next steps.
